﻿namespace Calculator_232911C
{
    partial class MainForm_232911C
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(MainForm_232911C));
            this.lblID = new System.Windows.Forms.Label();
            this.Entry_txtbox = new System.Windows.Forms.TextBox();
            this.btn1 = new System.Windows.Forms.Button();
            this.btn2 = new System.Windows.Forms.Button();
            this.btn3 = new System.Windows.Forms.Button();
            this.btn4 = new System.Windows.Forms.Button();
            this.btn5 = new System.Windows.Forms.Button();
            this.btn6 = new System.Windows.Forms.Button();
            this.btn7 = new System.Windows.Forms.Button();
            this.btn8 = new System.Windows.Forms.Button();
            this.btn9 = new System.Windows.Forms.Button();
            this.btn0 = new System.Windows.Forms.Button();
            this.btnDot = new System.Windows.Forms.Button();
            this.btnAdd = new System.Windows.Forms.Button();
            this.btnAC = new System.Windows.Forms.Button();
            this.btnSqrt = new System.Windows.Forms.Button();
            this.btnEqual = new System.Windows.Forms.Button();
            this.btnSubtract = new System.Windows.Forms.Button();
            this.btnSquare = new System.Windows.Forms.Button();
            this.txtEntryAns = new System.Windows.Forms.TextBox();
            this.btnMultiply = new System.Windows.Forms.Button();
            this.btnDivide = new System.Windows.Forms.Button();
            this.btnMod = new System.Windows.Forms.Button();
            this.btnMode = new System.Windows.Forms.Button();
            this.btnSinorLg = new System.Windows.Forms.Button();
            this.btnCosorLn = new System.Windows.Forms.Button();
            this.btnTanorex = new System.Windows.Forms.Button();
            this.btnreciprocal = new System.Windows.Forms.Button();
            this.btnsignflip = new System.Windows.Forms.Button();
            this.btn10xorxa = new System.Windows.Forms.Button();
            this.btnBackspace = new System.Windows.Forms.Button();
            this.btnTrigLog = new System.Windows.Forms.Button();
            this.btnDegRad = new System.Windows.Forms.Button();
            this.lblDegRad = new System.Windows.Forms.Label();
            this.KBsoundchkbox = new System.Windows.Forms.CheckBox();
            this.Speakerchkbox = new System.Windows.Forms.CheckBox();
            this.panelxtrabtns = new System.Windows.Forms.Panel();
            this.btnarctan = new System.Windows.Forms.Button();
            this.btnarcsin = new System.Windows.Forms.Button();
            this.btntanh = new System.Windows.Forms.Button();
            this.btncosh = new System.Windows.Forms.Button();
            this.btnsinh = new System.Windows.Forms.Button();
            this.btncopy = new System.Windows.Forms.Button();
            this.panelxtrabtns.SuspendLayout();
            this.SuspendLayout();
            // 
            // lblID
            // 
            this.lblID.AutoSize = true;
            this.lblID.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.lblID.Location = new System.Drawing.Point(12, 655);
            this.lblID.Name = "lblID";
            this.lblID.Size = new System.Drawing.Size(324, 20);
            this.lblID.TabIndex = 0;
            this.lblID.Text = "Done By: Yeo Keng En (232911C) Group:E1";
            this.lblID.Click += new System.EventHandler(this.lblID_Click);
            // 
            // Entry_txtbox
            // 
            this.Entry_txtbox.BackColor = System.Drawing.Color.PaleGreen;
            this.Entry_txtbox.Font = new System.Drawing.Font("OCR A Extended", 15F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Entry_txtbox.ForeColor = System.Drawing.Color.DimGray;
            this.Entry_txtbox.Location = new System.Drawing.Point(16, 48);
            this.Entry_txtbox.Multiline = true;
            this.Entry_txtbox.Name = "Entry_txtbox";
            this.Entry_txtbox.ReadOnly = true;
            this.Entry_txtbox.Size = new System.Drawing.Size(494, 45);
            this.Entry_txtbox.TabIndex = 1;
            this.Entry_txtbox.KeyDown += new System.Windows.Forms.KeyEventHandler(this.BtnPress_Keydown);
            // 
            // btn1
            // 
            this.btn1.BackColor = System.Drawing.Color.Black;
            this.btn1.FlatAppearance.BorderColor = System.Drawing.Color.White;
            this.btn1.FlatAppearance.BorderSize = 2;
            this.btn1.FlatAppearance.MouseDownBackColor = System.Drawing.Color.ForestGreen;
            this.btn1.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(20)))), ((int)(((byte)(20)))), ((int)(((byte)(20)))));
            this.btn1.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn1.Font = new System.Drawing.Font("OCR A Extended", 16F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn1.ForeColor = System.Drawing.Color.WhiteSmoke;
            this.btn1.Location = new System.Drawing.Point(16, 483);
            this.btn1.Name = "btn1";
            this.btn1.Size = new System.Drawing.Size(60, 60);
            this.btn1.TabIndex = 3;
            this.btn1.Text = "1";
            this.btn1.UseVisualStyleBackColor = false;
            this.btn1.Click += new System.EventHandler(this.numPad_Click);
            // 
            // btn2
            // 
            this.btn2.BackColor = System.Drawing.Color.Black;
            this.btn2.FlatAppearance.BorderColor = System.Drawing.Color.White;
            this.btn2.FlatAppearance.BorderSize = 2;
            this.btn2.FlatAppearance.MouseDownBackColor = System.Drawing.Color.ForestGreen;
            this.btn2.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(20)))), ((int)(((byte)(20)))), ((int)(((byte)(20)))));
            this.btn2.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn2.Font = new System.Drawing.Font("OCR A Extended", 16F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn2.ForeColor = System.Drawing.Color.WhiteSmoke;
            this.btn2.Location = new System.Drawing.Point(97, 483);
            this.btn2.Name = "btn2";
            this.btn2.Size = new System.Drawing.Size(60, 60);
            this.btn2.TabIndex = 4;
            this.btn2.Text = "2";
            this.btn2.UseVisualStyleBackColor = false;
            this.btn2.Click += new System.EventHandler(this.numPad_Click);
            // 
            // btn3
            // 
            this.btn3.BackColor = System.Drawing.Color.Black;
            this.btn3.FlatAppearance.BorderColor = System.Drawing.Color.White;
            this.btn3.FlatAppearance.BorderSize = 2;
            this.btn3.FlatAppearance.MouseDownBackColor = System.Drawing.Color.ForestGreen;
            this.btn3.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(20)))), ((int)(((byte)(20)))), ((int)(((byte)(20)))));
            this.btn3.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn3.Font = new System.Drawing.Font("OCR A Extended", 16F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn3.ForeColor = System.Drawing.Color.WhiteSmoke;
            this.btn3.Location = new System.Drawing.Point(178, 483);
            this.btn3.Name = "btn3";
            this.btn3.Size = new System.Drawing.Size(60, 60);
            this.btn3.TabIndex = 5;
            this.btn3.Text = "3";
            this.btn3.UseVisualStyleBackColor = false;
            this.btn3.Click += new System.EventHandler(this.numPad_Click);
            // 
            // btn4
            // 
            this.btn4.BackColor = System.Drawing.Color.Black;
            this.btn4.FlatAppearance.BorderColor = System.Drawing.Color.White;
            this.btn4.FlatAppearance.BorderSize = 2;
            this.btn4.FlatAppearance.MouseDownBackColor = System.Drawing.Color.ForestGreen;
            this.btn4.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(20)))), ((int)(((byte)(20)))), ((int)(((byte)(20)))));
            this.btn4.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn4.Font = new System.Drawing.Font("OCR A Extended", 16F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn4.ForeColor = System.Drawing.Color.WhiteSmoke;
            this.btn4.Location = new System.Drawing.Point(16, 402);
            this.btn4.Name = "btn4";
            this.btn4.Size = new System.Drawing.Size(60, 60);
            this.btn4.TabIndex = 6;
            this.btn4.Text = "4";
            this.btn4.UseVisualStyleBackColor = false;
            this.btn4.Click += new System.EventHandler(this.numPad_Click);
            // 
            // btn5
            // 
            this.btn5.BackColor = System.Drawing.Color.Black;
            this.btn5.FlatAppearance.BorderColor = System.Drawing.Color.White;
            this.btn5.FlatAppearance.BorderSize = 2;
            this.btn5.FlatAppearance.MouseDownBackColor = System.Drawing.Color.ForestGreen;
            this.btn5.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(20)))), ((int)(((byte)(20)))), ((int)(((byte)(20)))));
            this.btn5.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn5.Font = new System.Drawing.Font("OCR A Extended", 16F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn5.ForeColor = System.Drawing.Color.WhiteSmoke;
            this.btn5.Location = new System.Drawing.Point(97, 402);
            this.btn5.Name = "btn5";
            this.btn5.Size = new System.Drawing.Size(60, 60);
            this.btn5.TabIndex = 7;
            this.btn5.Text = "5";
            this.btn5.UseVisualStyleBackColor = false;
            this.btn5.Click += new System.EventHandler(this.numPad_Click);
            // 
            // btn6
            // 
            this.btn6.BackColor = System.Drawing.Color.Black;
            this.btn6.FlatAppearance.BorderColor = System.Drawing.Color.White;
            this.btn6.FlatAppearance.BorderSize = 2;
            this.btn6.FlatAppearance.MouseDownBackColor = System.Drawing.Color.ForestGreen;
            this.btn6.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(20)))), ((int)(((byte)(20)))), ((int)(((byte)(20)))));
            this.btn6.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn6.Font = new System.Drawing.Font("OCR A Extended", 16F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn6.ForeColor = System.Drawing.Color.WhiteSmoke;
            this.btn6.Location = new System.Drawing.Point(178, 402);
            this.btn6.Name = "btn6";
            this.btn6.Size = new System.Drawing.Size(60, 60);
            this.btn6.TabIndex = 8;
            this.btn6.Text = "6";
            this.btn6.UseVisualStyleBackColor = false;
            this.btn6.Click += new System.EventHandler(this.numPad_Click);
            // 
            // btn7
            // 
            this.btn7.BackColor = System.Drawing.Color.Black;
            this.btn7.FlatAppearance.BorderColor = System.Drawing.Color.White;
            this.btn7.FlatAppearance.BorderSize = 2;
            this.btn7.FlatAppearance.MouseDownBackColor = System.Drawing.Color.ForestGreen;
            this.btn7.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(20)))), ((int)(((byte)(20)))), ((int)(((byte)(20)))));
            this.btn7.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn7.Font = new System.Drawing.Font("OCR A Extended", 16F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn7.ForeColor = System.Drawing.Color.WhiteSmoke;
            this.btn7.Location = new System.Drawing.Point(16, 319);
            this.btn7.Name = "btn7";
            this.btn7.Size = new System.Drawing.Size(60, 60);
            this.btn7.TabIndex = 9;
            this.btn7.Text = "7";
            this.btn7.UseVisualStyleBackColor = false;
            this.btn7.Click += new System.EventHandler(this.numPad_Click);
            // 
            // btn8
            // 
            this.btn8.BackColor = System.Drawing.Color.Black;
            this.btn8.FlatAppearance.BorderColor = System.Drawing.Color.White;
            this.btn8.FlatAppearance.BorderSize = 2;
            this.btn8.FlatAppearance.MouseDownBackColor = System.Drawing.Color.ForestGreen;
            this.btn8.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(20)))), ((int)(((byte)(20)))), ((int)(((byte)(20)))));
            this.btn8.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn8.Font = new System.Drawing.Font("OCR A Extended", 16F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn8.ForeColor = System.Drawing.Color.WhiteSmoke;
            this.btn8.Location = new System.Drawing.Point(97, 319);
            this.btn8.Name = "btn8";
            this.btn8.Size = new System.Drawing.Size(60, 60);
            this.btn8.TabIndex = 10;
            this.btn8.Text = "8";
            this.btn8.UseVisualStyleBackColor = false;
            this.btn8.Click += new System.EventHandler(this.numPad_Click);
            // 
            // btn9
            // 
            this.btn9.BackColor = System.Drawing.Color.Black;
            this.btn9.FlatAppearance.BorderColor = System.Drawing.Color.White;
            this.btn9.FlatAppearance.BorderSize = 2;
            this.btn9.FlatAppearance.MouseDownBackColor = System.Drawing.Color.ForestGreen;
            this.btn9.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(20)))), ((int)(((byte)(20)))), ((int)(((byte)(20)))));
            this.btn9.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn9.Font = new System.Drawing.Font("OCR A Extended", 16F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn9.ForeColor = System.Drawing.Color.WhiteSmoke;
            this.btn9.Location = new System.Drawing.Point(178, 319);
            this.btn9.Name = "btn9";
            this.btn9.Size = new System.Drawing.Size(60, 60);
            this.btn9.TabIndex = 11;
            this.btn9.Text = "9";
            this.btn9.UseVisualStyleBackColor = false;
            this.btn9.Click += new System.EventHandler(this.numPad_Click);
            // 
            // btn0
            // 
            this.btn0.BackColor = System.Drawing.Color.Black;
            this.btn0.FlatAppearance.BorderColor = System.Drawing.Color.White;
            this.btn0.FlatAppearance.BorderSize = 2;
            this.btn0.FlatAppearance.MouseDownBackColor = System.Drawing.Color.ForestGreen;
            this.btn0.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(20)))), ((int)(((byte)(20)))), ((int)(((byte)(20)))));
            this.btn0.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn0.Font = new System.Drawing.Font("OCR A Extended", 16F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn0.ForeColor = System.Drawing.Color.WhiteSmoke;
            this.btn0.Location = new System.Drawing.Point(12, 562);
            this.btn0.Name = "btn0";
            this.btn0.Size = new System.Drawing.Size(145, 60);
            this.btn0.TabIndex = 12;
            this.btn0.Text = "0";
            this.btn0.UseVisualStyleBackColor = false;
            this.btn0.Click += new System.EventHandler(this.numPad_Click);
            // 
            // btnDot
            // 
            this.btnDot.BackColor = System.Drawing.Color.Black;
            this.btnDot.FlatAppearance.BorderColor = System.Drawing.Color.White;
            this.btnDot.FlatAppearance.BorderSize = 2;
            this.btnDot.FlatAppearance.MouseDownBackColor = System.Drawing.Color.ForestGreen;
            this.btnDot.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(20)))), ((int)(((byte)(20)))), ((int)(((byte)(20)))));
            this.btnDot.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnDot.Font = new System.Drawing.Font("OCR A Extended", 16F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnDot.ForeColor = System.Drawing.Color.WhiteSmoke;
            this.btnDot.Location = new System.Drawing.Point(178, 562);
            this.btnDot.Name = "btnDot";
            this.btnDot.Size = new System.Drawing.Size(60, 60);
            this.btnDot.TabIndex = 13;
            this.btnDot.Text = ".";
            this.btnDot.UseVisualStyleBackColor = false;
            this.btnDot.Click += new System.EventHandler(this.numPad_Click);
            // 
            // btnAdd
            // 
            this.btnAdd.BackColor = System.Drawing.Color.Black;
            this.btnAdd.FlatAppearance.BorderColor = System.Drawing.Color.White;
            this.btnAdd.FlatAppearance.BorderSize = 2;
            this.btnAdd.FlatAppearance.MouseDownBackColor = System.Drawing.Color.ForestGreen;
            this.btnAdd.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(20)))), ((int)(((byte)(20)))), ((int)(((byte)(20)))));
            this.btnAdd.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnAdd.Font = new System.Drawing.Font("OCR A Extended", 16F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnAdd.ForeColor = System.Drawing.Color.WhiteSmoke;
            this.btnAdd.Location = new System.Drawing.Point(261, 402);
            this.btnAdd.Name = "btnAdd";
            this.btnAdd.Size = new System.Drawing.Size(60, 60);
            this.btnAdd.TabIndex = 14;
            this.btnAdd.Tag = "Add";
            this.btnAdd.Text = "+";
            this.btnAdd.UseVisualStyleBackColor = false;
            this.btnAdd.Click += new System.EventHandler(this.operator_Click);
            // 
            // btnAC
            // 
            this.btnAC.BackColor = System.Drawing.Color.Black;
            this.btnAC.FlatAppearance.BorderColor = System.Drawing.Color.OrangeRed;
            this.btnAC.FlatAppearance.BorderSize = 2;
            this.btnAC.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Lime;
            this.btnAC.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.btnAC.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnAC.Font = new System.Drawing.Font("OCR A Extended", 11F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnAC.ForeColor = System.Drawing.Color.Firebrick;
            this.btnAC.Location = new System.Drawing.Point(343, 319);
            this.btnAC.Name = "btnAC";
            this.btnAC.Size = new System.Drawing.Size(62, 60);
            this.btnAC.TabIndex = 15;
            this.btnAC.Tag = "AC";
            this.btnAC.Text = "AC";
            this.btnAC.UseVisualStyleBackColor = false;
            this.btnAC.Click += new System.EventHandler(this.btnAC_Click);
            // 
            // btnSqrt
            // 
            this.btnSqrt.BackColor = System.Drawing.Color.Black;
            this.btnSqrt.FlatAppearance.BorderColor = System.Drawing.Color.White;
            this.btnSqrt.FlatAppearance.BorderSize = 2;
            this.btnSqrt.FlatAppearance.MouseDownBackColor = System.Drawing.Color.ForestGreen;
            this.btnSqrt.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(20)))), ((int)(((byte)(20)))), ((int)(((byte)(20)))));
            this.btnSqrt.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnSqrt.Font = new System.Drawing.Font("OCR A Extended", 16F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnSqrt.ForeColor = System.Drawing.Color.WhiteSmoke;
            this.btnSqrt.Location = new System.Drawing.Point(426, 402);
            this.btnSqrt.Name = "btnSqrt";
            this.btnSqrt.Size = new System.Drawing.Size(67, 60);
            this.btnSqrt.TabIndex = 16;
            this.btnSqrt.Tag = "";
            this.btnSqrt.UseVisualStyleBackColor = false;
            this.btnSqrt.Click += new System.EventHandler(this.u_operator_Click);
            this.btnSqrt.KeyDown += new System.Windows.Forms.KeyEventHandler(this.BtnPress_Keydown);
            // 
            // btnEqual
            // 
            this.btnEqual.BackColor = System.Drawing.Color.Black;
            this.btnEqual.FlatAppearance.BorderColor = System.Drawing.Color.White;
            this.btnEqual.FlatAppearance.BorderSize = 2;
            this.btnEqual.FlatAppearance.MouseDownBackColor = System.Drawing.Color.ForestGreen;
            this.btnEqual.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(20)))), ((int)(((byte)(20)))), ((int)(((byte)(20)))));
            this.btnEqual.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnEqual.Font = new System.Drawing.Font("OCR A Extended", 16F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnEqual.ForeColor = System.Drawing.Color.WhiteSmoke;
            this.btnEqual.Location = new System.Drawing.Point(261, 562);
            this.btnEqual.Name = "btnEqual";
            this.btnEqual.Size = new System.Drawing.Size(144, 60);
            this.btnEqual.TabIndex = 17;
            this.btnEqual.Tag = "Equal";
            this.btnEqual.Text = "=";
            this.btnEqual.UseVisualStyleBackColor = false;
            this.btnEqual.Click += new System.EventHandler(this.btnEqual_Click);
            this.btnEqual.KeyDown += new System.Windows.Forms.KeyEventHandler(this.BtnPress_Keydown);
            // 
            // btnSubtract
            // 
            this.btnSubtract.BackColor = System.Drawing.Color.Black;
            this.btnSubtract.FlatAppearance.BorderColor = System.Drawing.Color.White;
            this.btnSubtract.FlatAppearance.BorderSize = 2;
            this.btnSubtract.FlatAppearance.MouseDownBackColor = System.Drawing.Color.ForestGreen;
            this.btnSubtract.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(20)))), ((int)(((byte)(20)))), ((int)(((byte)(20)))));
            this.btnSubtract.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnSubtract.Font = new System.Drawing.Font("OCR A Extended", 16F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnSubtract.ForeColor = System.Drawing.Color.WhiteSmoke;
            this.btnSubtract.Location = new System.Drawing.Point(345, 402);
            this.btnSubtract.Name = "btnSubtract";
            this.btnSubtract.Size = new System.Drawing.Size(60, 60);
            this.btnSubtract.TabIndex = 18;
            this.btnSubtract.Tag = "Minus";
            this.btnSubtract.Text = "-";
            this.btnSubtract.UseVisualStyleBackColor = false;
            this.btnSubtract.Click += new System.EventHandler(this.operator_Click);
            // 
            // btnSquare
            // 
            this.btnSquare.BackColor = System.Drawing.Color.Black;
            this.btnSquare.FlatAppearance.BorderColor = System.Drawing.Color.White;
            this.btnSquare.FlatAppearance.BorderSize = 2;
            this.btnSquare.FlatAppearance.MouseDownBackColor = System.Drawing.Color.ForestGreen;
            this.btnSquare.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(20)))), ((int)(((byte)(20)))), ((int)(((byte)(20)))));
            this.btnSquare.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnSquare.Font = new System.Drawing.Font("OCR A Extended", 14F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnSquare.ForeColor = System.Drawing.Color.WhiteSmoke;
            this.btnSquare.Location = new System.Drawing.Point(426, 321);
            this.btnSquare.Name = "btnSquare";
            this.btnSquare.Size = new System.Drawing.Size(67, 60);
            this.btnSquare.TabIndex = 19;
            this.btnSquare.Tag = "";
            this.btnSquare.UseVisualStyleBackColor = false;
            this.btnSquare.Click += new System.EventHandler(this.u_operator_Click);
            this.btnSquare.KeyDown += new System.Windows.Forms.KeyEventHandler(this.BtnPress_Keydown);
            // 
            // txtEntryAns
            // 
            this.txtEntryAns.BackColor = System.Drawing.Color.PaleGreen;
            this.txtEntryAns.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.txtEntryAns.Font = new System.Drawing.Font("OCR A Extended", 28F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtEntryAns.Location = new System.Drawing.Point(16, 86);
            this.txtEntryAns.Name = "txtEntryAns";
            this.txtEntryAns.ReadOnly = true;
            this.txtEntryAns.Size = new System.Drawing.Size(494, 58);
            this.txtEntryAns.TabIndex = 20;
            this.txtEntryAns.Text = "0";
            this.txtEntryAns.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.txtEntryAns.TextChanged += new System.EventHandler(this.txtEntryAns_TextChanged);
            // 
            // btnMultiply
            // 
            this.btnMultiply.BackColor = System.Drawing.Color.Black;
            this.btnMultiply.FlatAppearance.BorderColor = System.Drawing.Color.White;
            this.btnMultiply.FlatAppearance.BorderSize = 2;
            this.btnMultiply.FlatAppearance.MouseDownBackColor = System.Drawing.Color.ForestGreen;
            this.btnMultiply.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(20)))), ((int)(((byte)(20)))), ((int)(((byte)(20)))));
            this.btnMultiply.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnMultiply.Font = new System.Drawing.Font("OCR A Extended", 16F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnMultiply.ForeColor = System.Drawing.Color.WhiteSmoke;
            this.btnMultiply.Location = new System.Drawing.Point(259, 483);
            this.btnMultiply.Name = "btnMultiply";
            this.btnMultiply.Size = new System.Drawing.Size(60, 60);
            this.btnMultiply.TabIndex = 21;
            this.btnMultiply.Tag = "Multiply";
            this.btnMultiply.Text = "x";
            this.btnMultiply.UseVisualStyleBackColor = false;
            this.btnMultiply.Click += new System.EventHandler(this.operator_Click);
            // 
            // btnDivide
            // 
            this.btnDivide.BackColor = System.Drawing.Color.Black;
            this.btnDivide.FlatAppearance.BorderColor = System.Drawing.Color.White;
            this.btnDivide.FlatAppearance.BorderSize = 2;
            this.btnDivide.FlatAppearance.MouseDownBackColor = System.Drawing.Color.ForestGreen;
            this.btnDivide.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(20)))), ((int)(((byte)(20)))), ((int)(((byte)(20)))));
            this.btnDivide.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnDivide.Font = new System.Drawing.Font("OCR A Extended", 16F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnDivide.ForeColor = System.Drawing.Color.WhiteSmoke;
            this.btnDivide.Location = new System.Drawing.Point(345, 483);
            this.btnDivide.Name = "btnDivide";
            this.btnDivide.Size = new System.Drawing.Size(60, 60);
            this.btnDivide.TabIndex = 22;
            this.btnDivide.Tag = "Divide";
            this.btnDivide.Text = "÷";
            this.btnDivide.UseVisualStyleBackColor = false;
            this.btnDivide.Click += new System.EventHandler(this.operator_Click);
            // 
            // btnMod
            // 
            this.btnMod.BackColor = System.Drawing.Color.Black;
            this.btnMod.FlatAppearance.BorderColor = System.Drawing.Color.White;
            this.btnMod.FlatAppearance.BorderSize = 2;
            this.btnMod.FlatAppearance.MouseDownBackColor = System.Drawing.Color.ForestGreen;
            this.btnMod.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(20)))), ((int)(((byte)(20)))), ((int)(((byte)(20)))));
            this.btnMod.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnMod.Font = new System.Drawing.Font("OCR A Extended", 16F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnMod.ForeColor = System.Drawing.Color.WhiteSmoke;
            this.btnMod.Location = new System.Drawing.Point(259, 319);
            this.btnMod.Name = "btnMod";
            this.btnMod.Size = new System.Drawing.Size(60, 60);
            this.btnMod.TabIndex = 23;
            this.btnMod.Tag = "Mod";
            this.btnMod.Text = "%";
            this.btnMod.UseVisualStyleBackColor = false;
            this.btnMod.Click += new System.EventHandler(this.operator_Click);
            // 
            // btnMode
            // 
            this.btnMode.BackColor = System.Drawing.Color.Black;
            this.btnMode.FlatAppearance.BorderColor = System.Drawing.Color.White;
            this.btnMode.FlatAppearance.BorderSize = 2;
            this.btnMode.FlatAppearance.MouseDownBackColor = System.Drawing.Color.ForestGreen;
            this.btnMode.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(20)))), ((int)(((byte)(20)))), ((int)(((byte)(20)))));
            this.btnMode.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnMode.Font = new System.Drawing.Font("OCR A Extended", 7F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnMode.ForeColor = System.Drawing.Color.WhiteSmoke;
            this.btnMode.Location = new System.Drawing.Point(16, 169);
            this.btnMode.Name = "btnMode";
            this.btnMode.Size = new System.Drawing.Size(78, 46);
            this.btnMode.TabIndex = 24;
            this.btnMode.Tag = "STD";
            this.btnMode.Text = "STD";
            this.btnMode.UseVisualStyleBackColor = false;
            this.btnMode.Click += new System.EventHandler(this.btnMode_Click);
            // 
            // btnSinorLg
            // 
            this.btnSinorLg.BackColor = System.Drawing.Color.Black;
            this.btnSinorLg.FlatAppearance.BorderColor = System.Drawing.Color.White;
            this.btnSinorLg.FlatAppearance.BorderSize = 2;
            this.btnSinorLg.FlatAppearance.MouseDownBackColor = System.Drawing.Color.ForestGreen;
            this.btnSinorLg.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(20)))), ((int)(((byte)(20)))), ((int)(((byte)(20)))));
            this.btnSinorLg.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnSinorLg.Font = new System.Drawing.Font("OCR A Extended", 16F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnSinorLg.ForeColor = System.Drawing.Color.WhiteSmoke;
            this.btnSinorLg.Location = new System.Drawing.Point(215, 234);
            this.btnSinorLg.Name = "btnSinorLg";
            this.btnSinorLg.Size = new System.Drawing.Size(92, 60);
            this.btnSinorLg.TabIndex = 25;
            this.btnSinorLg.UseVisualStyleBackColor = false;
            this.btnSinorLg.Click += new System.EventHandler(this.u_operator_Click);
            // 
            // btnCosorLn
            // 
            this.btnCosorLn.BackColor = System.Drawing.Color.Black;
            this.btnCosorLn.FlatAppearance.BorderColor = System.Drawing.Color.White;
            this.btnCosorLn.FlatAppearance.BorderSize = 2;
            this.btnCosorLn.FlatAppearance.MouseDownBackColor = System.Drawing.Color.ForestGreen;
            this.btnCosorLn.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(20)))), ((int)(((byte)(20)))), ((int)(((byte)(20)))));
            this.btnCosorLn.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnCosorLn.Font = new System.Drawing.Font("OCR A Extended", 16F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnCosorLn.ForeColor = System.Drawing.Color.WhiteSmoke;
            this.btnCosorLn.Location = new System.Drawing.Point(113, 234);
            this.btnCosorLn.Name = "btnCosorLn";
            this.btnCosorLn.Size = new System.Drawing.Size(93, 60);
            this.btnCosorLn.TabIndex = 26;
            this.btnCosorLn.UseVisualStyleBackColor = false;
            this.btnCosorLn.Click += new System.EventHandler(this.u_operator_Click);
            // 
            // btnTanorex
            // 
            this.btnTanorex.BackColor = System.Drawing.Color.Black;
            this.btnTanorex.FlatAppearance.BorderColor = System.Drawing.Color.White;
            this.btnTanorex.FlatAppearance.BorderSize = 2;
            this.btnTanorex.FlatAppearance.MouseDownBackColor = System.Drawing.Color.ForestGreen;
            this.btnTanorex.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(20)))), ((int)(((byte)(20)))), ((int)(((byte)(20)))));
            this.btnTanorex.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnTanorex.Font = new System.Drawing.Font("OCR A Extended", 16F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnTanorex.ForeColor = System.Drawing.Color.WhiteSmoke;
            this.btnTanorex.Location = new System.Drawing.Point(12, 234);
            this.btnTanorex.Name = "btnTanorex";
            this.btnTanorex.Size = new System.Drawing.Size(95, 60);
            this.btnTanorex.TabIndex = 27;
            this.btnTanorex.UseVisualStyleBackColor = false;
            this.btnTanorex.Click += new System.EventHandler(this.u_operator_Click);
            // 
            // btnreciprocal
            // 
            this.btnreciprocal.BackColor = System.Drawing.Color.Black;
            this.btnreciprocal.FlatAppearance.BorderColor = System.Drawing.Color.White;
            this.btnreciprocal.FlatAppearance.BorderSize = 2;
            this.btnreciprocal.FlatAppearance.MouseDownBackColor = System.Drawing.Color.ForestGreen;
            this.btnreciprocal.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(20)))), ((int)(((byte)(20)))), ((int)(((byte)(20)))));
            this.btnreciprocal.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnreciprocal.Font = new System.Drawing.Font("OCR A Extended", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnreciprocal.ForeColor = System.Drawing.Color.WhiteSmoke;
            this.btnreciprocal.Location = new System.Drawing.Point(426, 483);
            this.btnreciprocal.Name = "btnreciprocal";
            this.btnreciprocal.Size = new System.Drawing.Size(67, 60);
            this.btnreciprocal.TabIndex = 28;
            this.btnreciprocal.Tag = "";
            this.btnreciprocal.UseVisualStyleBackColor = false;
            this.btnreciprocal.Click += new System.EventHandler(this.u_operator_Click);
            // 
            // btnsignflip
            // 
            this.btnsignflip.BackColor = System.Drawing.Color.Black;
            this.btnsignflip.FlatAppearance.BorderColor = System.Drawing.Color.White;
            this.btnsignflip.FlatAppearance.BorderSize = 2;
            this.btnsignflip.FlatAppearance.MouseDownBackColor = System.Drawing.Color.ForestGreen;
            this.btnsignflip.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(20)))), ((int)(((byte)(20)))), ((int)(((byte)(20)))));
            this.btnsignflip.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnsignflip.Font = new System.Drawing.Font("OCR A Extended", 11F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnsignflip.ForeColor = System.Drawing.Color.WhiteSmoke;
            this.btnsignflip.Location = new System.Drawing.Point(426, 562);
            this.btnsignflip.Name = "btnsignflip";
            this.btnsignflip.Size = new System.Drawing.Size(67, 60);
            this.btnsignflip.TabIndex = 29;
            this.btnsignflip.Tag = "";
            this.btnsignflip.UseVisualStyleBackColor = false;
            this.btnsignflip.Click += new System.EventHandler(this.u_operator_Click);
            // 
            // btn10xorxa
            // 
            this.btn10xorxa.BackColor = System.Drawing.Color.Black;
            this.btn10xorxa.FlatAppearance.BorderColor = System.Drawing.Color.White;
            this.btn10xorxa.FlatAppearance.BorderSize = 2;
            this.btn10xorxa.FlatAppearance.MouseDownBackColor = System.Drawing.Color.ForestGreen;
            this.btn10xorxa.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(20)))), ((int)(((byte)(20)))), ((int)(((byte)(20)))));
            this.btn10xorxa.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn10xorxa.Font = new System.Drawing.Font("OCR A Extended", 16F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn10xorxa.ForeColor = System.Drawing.Color.WhiteSmoke;
            this.btn10xorxa.Location = new System.Drawing.Point(313, 234);
            this.btn10xorxa.Name = "btn10xorxa";
            this.btn10xorxa.Size = new System.Drawing.Size(92, 60);
            this.btn10xorxa.TabIndex = 30;
            this.btn10xorxa.UseVisualStyleBackColor = false;
            this.btn10xorxa.Click += new System.EventHandler(this.u_operator_Click);
            // 
            // btnBackspace
            // 
            this.btnBackspace.BackColor = System.Drawing.Color.Black;
            this.btnBackspace.FlatAppearance.BorderColor = System.Drawing.Color.OrangeRed;
            this.btnBackspace.FlatAppearance.BorderSize = 2;
            this.btnBackspace.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Lime;
            this.btnBackspace.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.btnBackspace.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnBackspace.Font = new System.Drawing.Font("OCR A Extended", 16F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnBackspace.ForeColor = System.Drawing.Color.Firebrick;
            this.btnBackspace.Location = new System.Drawing.Point(426, 234);
            this.btnBackspace.Name = "btnBackspace";
            this.btnBackspace.Size = new System.Drawing.Size(67, 63);
            this.btnBackspace.TabIndex = 31;
            this.btnBackspace.Tag = "";
            this.btnBackspace.Text = "⌫";
            this.btnBackspace.UseVisualStyleBackColor = false;
            this.btnBackspace.Click += new System.EventHandler(this.btnBackspace_Click);
            this.btnBackspace.KeyDown += new System.Windows.Forms.KeyEventHandler(this.BtnPress_Keydown);
            // 
            // btnTrigLog
            // 
            this.btnTrigLog.BackColor = System.Drawing.Color.Black;
            this.btnTrigLog.FlatAppearance.BorderColor = System.Drawing.Color.White;
            this.btnTrigLog.FlatAppearance.BorderSize = 2;
            this.btnTrigLog.FlatAppearance.MouseDownBackColor = System.Drawing.Color.ForestGreen;
            this.btnTrigLog.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(20)))), ((int)(((byte)(20)))), ((int)(((byte)(20)))));
            this.btnTrigLog.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnTrigLog.Font = new System.Drawing.Font("OCR A Extended", 7F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnTrigLog.ForeColor = System.Drawing.Color.WhiteSmoke;
            this.btnTrigLog.Location = new System.Drawing.Point(113, 169);
            this.btnTrigLog.Name = "btnTrigLog";
            this.btnTrigLog.Size = new System.Drawing.Size(77, 46);
            this.btnTrigLog.TabIndex = 32;
            this.btnTrigLog.Tag = "";
            this.btnTrigLog.Text = "Trig";
            this.btnTrigLog.UseVisualStyleBackColor = false;
            this.btnTrigLog.Click += new System.EventHandler(this.btnTrigLog_Click);
            // 
            // btnDegRad
            // 
            this.btnDegRad.BackColor = System.Drawing.Color.Black;
            this.btnDegRad.FlatAppearance.BorderColor = System.Drawing.Color.White;
            this.btnDegRad.FlatAppearance.BorderSize = 2;
            this.btnDegRad.FlatAppearance.MouseDownBackColor = System.Drawing.Color.ForestGreen;
            this.btnDegRad.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(20)))), ((int)(((byte)(20)))), ((int)(((byte)(20)))));
            this.btnDegRad.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnDegRad.Font = new System.Drawing.Font("OCR A Extended", 7F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnDegRad.ForeColor = System.Drawing.Color.WhiteSmoke;
            this.btnDegRad.Location = new System.Drawing.Point(205, 169);
            this.btnDegRad.Name = "btnDegRad";
            this.btnDegRad.Size = new System.Drawing.Size(77, 46);
            this.btnDegRad.TabIndex = 33;
            this.btnDegRad.Tag = "";
            this.btnDegRad.Text = "Deg";
            this.btnDegRad.UseVisualStyleBackColor = false;
            this.btnDegRad.Click += new System.EventHandler(this.btnDegRad_Click);
            // 
            // lblDegRad
            // 
            this.lblDegRad.AutoSize = true;
            this.lblDegRad.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblDegRad.ForeColor = System.Drawing.SystemColors.ButtonFace;
            this.lblDegRad.Location = new System.Drawing.Point(139, 9);
            this.lblDegRad.Name = "lblDegRad";
            this.lblDegRad.Size = new System.Drawing.Size(89, 29);
            this.lblDegRad.TabIndex = 35;
            this.lblDegRad.Text = "Radian";
            // 
            // KBsoundchkbox
            // 
            this.KBsoundchkbox.AutoSize = true;
            this.KBsoundchkbox.ForeColor = System.Drawing.SystemColors.Control;
            this.KBsoundchkbox.Location = new System.Drawing.Point(319, 159);
            this.KBsoundchkbox.Name = "KBsoundchkbox";
            this.KBsoundchkbox.Size = new System.Drawing.Size(79, 24);
            this.KBsoundchkbox.TabIndex = 36;
            this.KBsoundchkbox.Text = "sound";
            this.KBsoundchkbox.UseVisualStyleBackColor = true;
            this.KBsoundchkbox.CheckedChanged += new System.EventHandler(this.cbKBsound_CheckedChanged);
            // 
            // Speakerchkbox
            // 
            this.Speakerchkbox.AutoSize = true;
            this.Speakerchkbox.ForeColor = System.Drawing.SystemColors.Control;
            this.Speakerchkbox.Location = new System.Drawing.Point(319, 191);
            this.Speakerchkbox.Name = "Speakerchkbox";
            this.Speakerchkbox.Size = new System.Drawing.Size(95, 24);
            this.Speakerchkbox.TabIndex = 37;
            this.Speakerchkbox.Text = "Speaker";
            this.Speakerchkbox.UseVisualStyleBackColor = true;
            this.Speakerchkbox.CheckedChanged += new System.EventHandler(this.cbSpeaker_CheckChanged);
            // 
            // panelxtrabtns
            // 
            this.panelxtrabtns.BackColor = System.Drawing.SystemColors.ControlDarkDark;
            this.panelxtrabtns.Controls.Add(this.btnarctan);
            this.panelxtrabtns.Controls.Add(this.btnarcsin);
            this.panelxtrabtns.Controls.Add(this.btntanh);
            this.panelxtrabtns.Controls.Add(this.btncosh);
            this.panelxtrabtns.Controls.Add(this.btnsinh);
            this.panelxtrabtns.Location = new System.Drawing.Point(516, 209);
            this.panelxtrabtns.Name = "panelxtrabtns";
            this.panelxtrabtns.Size = new System.Drawing.Size(99, 413);
            this.panelxtrabtns.TabIndex = 38;
            this.panelxtrabtns.Tag = "Xtra btns";
            this.panelxtrabtns.Click += new System.EventHandler(this.btnMode_Click);
            // 
            // btnarctan
            // 
            this.btnarctan.BackColor = System.Drawing.Color.Black;
            this.btnarctan.FlatAppearance.BorderColor = System.Drawing.Color.White;
            this.btnarctan.FlatAppearance.BorderSize = 2;
            this.btnarctan.FlatAppearance.MouseDownBackColor = System.Drawing.Color.ForestGreen;
            this.btnarctan.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(20)))), ((int)(((byte)(20)))), ((int)(((byte)(20)))));
            this.btnarctan.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnarctan.Font = new System.Drawing.Font("OCR A Extended", 7F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnarctan.ForeColor = System.Drawing.Color.WhiteSmoke;
            this.btnarctan.Location = new System.Drawing.Point(1, 25);
            this.btnarctan.Name = "btnarctan";
            this.btnarctan.Size = new System.Drawing.Size(95, 60);
            this.btnarctan.TabIndex = 41;
            this.btnarctan.Tag = "arctan";
            this.btnarctan.UseVisualStyleBackColor = false;
            this.btnarctan.Click += new System.EventHandler(this.u_operator_Click);
            // 
            // btnarcsin
            // 
            this.btnarcsin.BackColor = System.Drawing.Color.Black;
            this.btnarcsin.FlatAppearance.BorderColor = System.Drawing.Color.White;
            this.btnarcsin.FlatAppearance.BorderSize = 2;
            this.btnarcsin.FlatAppearance.MouseDownBackColor = System.Drawing.Color.ForestGreen;
            this.btnarcsin.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(20)))), ((int)(((byte)(20)))), ((int)(((byte)(20)))));
            this.btnarcsin.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnarcsin.Font = new System.Drawing.Font("OCR A Extended", 7F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnarcsin.ForeColor = System.Drawing.Color.WhiteSmoke;
            this.btnarcsin.Location = new System.Drawing.Point(0, 350);
            this.btnarcsin.Name = "btnarcsin";
            this.btnarcsin.Size = new System.Drawing.Size(95, 60);
            this.btnarcsin.TabIndex = 40;
            this.btnarcsin.Tag = "arcsin";
            this.btnarcsin.UseVisualStyleBackColor = false;
            this.btnarcsin.Click += new System.EventHandler(this.u_operator_Click);
            // 
            // btntanh
            // 
            this.btntanh.BackColor = System.Drawing.Color.Black;
            this.btntanh.FlatAppearance.BorderColor = System.Drawing.Color.White;
            this.btntanh.FlatAppearance.BorderSize = 2;
            this.btntanh.FlatAppearance.MouseDownBackColor = System.Drawing.Color.ForestGreen;
            this.btntanh.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(20)))), ((int)(((byte)(20)))), ((int)(((byte)(20)))));
            this.btntanh.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btntanh.Font = new System.Drawing.Font("OCR A Extended", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btntanh.ForeColor = System.Drawing.Color.WhiteSmoke;
            this.btntanh.Location = new System.Drawing.Point(0, 268);
            this.btntanh.Name = "btntanh";
            this.btntanh.Size = new System.Drawing.Size(95, 60);
            this.btntanh.TabIndex = 39;
            this.btntanh.Tag = "tanh";
            this.btntanh.UseVisualStyleBackColor = false;
            this.btntanh.Click += new System.EventHandler(this.u_operator_Click);
            // 
            // btncosh
            // 
            this.btncosh.BackColor = System.Drawing.Color.Black;
            this.btncosh.FlatAppearance.BorderColor = System.Drawing.Color.White;
            this.btncosh.FlatAppearance.BorderSize = 2;
            this.btncosh.FlatAppearance.MouseDownBackColor = System.Drawing.Color.ForestGreen;
            this.btncosh.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(20)))), ((int)(((byte)(20)))), ((int)(((byte)(20)))));
            this.btncosh.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btncosh.Font = new System.Drawing.Font("OCR A Extended", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btncosh.ForeColor = System.Drawing.Color.WhiteSmoke;
            this.btncosh.Location = new System.Drawing.Point(1, 112);
            this.btncosh.Name = "btncosh";
            this.btncosh.Size = new System.Drawing.Size(95, 60);
            this.btncosh.TabIndex = 29;
            this.btncosh.Tag = "cosh";
            this.btncosh.UseVisualStyleBackColor = false;
            this.btncosh.Click += new System.EventHandler(this.u_operator_Click);
            // 
            // btnsinh
            // 
            this.btnsinh.BackColor = System.Drawing.Color.Black;
            this.btnsinh.FlatAppearance.BorderColor = System.Drawing.Color.White;
            this.btnsinh.FlatAppearance.BorderSize = 2;
            this.btnsinh.FlatAppearance.MouseDownBackColor = System.Drawing.Color.ForestGreen;
            this.btnsinh.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(20)))), ((int)(((byte)(20)))), ((int)(((byte)(20)))));
            this.btnsinh.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnsinh.Font = new System.Drawing.Font("OCR A Extended", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnsinh.ForeColor = System.Drawing.Color.WhiteSmoke;
            this.btnsinh.Location = new System.Drawing.Point(1, 193);
            this.btnsinh.Name = "btnsinh";
            this.btnsinh.Size = new System.Drawing.Size(95, 60);
            this.btnsinh.TabIndex = 28;
            this.btnsinh.Tag = "sinh";
            this.btnsinh.UseVisualStyleBackColor = false;
            this.btnsinh.Click += new System.EventHandler(this.u_operator_Click);
            // 
            // btncopy
            // 
            this.btncopy.BackColor = System.Drawing.Color.Black;
            this.btncopy.FlatAppearance.BorderColor = System.Drawing.Color.White;
            this.btncopy.FlatAppearance.BorderSize = 2;
            this.btncopy.FlatAppearance.MouseDownBackColor = System.Drawing.Color.ForestGreen;
            this.btncopy.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(20)))), ((int)(((byte)(20)))), ((int)(((byte)(20)))));
            this.btncopy.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btncopy.Font = new System.Drawing.Font("OCR A Extended", 7F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btncopy.ForeColor = System.Drawing.Color.WhiteSmoke;
            this.btncopy.Location = new System.Drawing.Point(426, 169);
            this.btncopy.Name = "btncopy";
            this.btncopy.Size = new System.Drawing.Size(77, 46);
            this.btncopy.TabIndex = 39;
            this.btncopy.Tag = "";
            this.btncopy.Text = "COPY";
            this.btncopy.UseVisualStyleBackColor = false;
            this.btncopy.Click += new System.EventHandler(this.btncopy_click);
            // 
            // MainForm_232911C
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.Black;
            this.ClientSize = new System.Drawing.Size(658, 684);
            this.Controls.Add(this.btncopy);
            this.Controls.Add(this.panelxtrabtns);
            this.Controls.Add(this.Speakerchkbox);
            this.Controls.Add(this.KBsoundchkbox);
            this.Controls.Add(this.lblDegRad);
            this.Controls.Add(this.btnMode);
            this.Controls.Add(this.btnDegRad);
            this.Controls.Add(this.btnTrigLog);
            this.Controls.Add(this.btnBackspace);
            this.Controls.Add(this.btn10xorxa);
            this.Controls.Add(this.btnsignflip);
            this.Controls.Add(this.btnreciprocal);
            this.Controls.Add(this.btnTanorex);
            this.Controls.Add(this.btnCosorLn);
            this.Controls.Add(this.btnSinorLg);
            this.Controls.Add(this.btnMod);
            this.Controls.Add(this.btnDivide);
            this.Controls.Add(this.btnMultiply);
            this.Controls.Add(this.txtEntryAns);
            this.Controls.Add(this.btnSquare);
            this.Controls.Add(this.btnSubtract);
            this.Controls.Add(this.btnEqual);
            this.Controls.Add(this.btnSqrt);
            this.Controls.Add(this.btnAC);
            this.Controls.Add(this.btnAdd);
            this.Controls.Add(this.btnDot);
            this.Controls.Add(this.btn0);
            this.Controls.Add(this.btn9);
            this.Controls.Add(this.btn8);
            this.Controls.Add(this.btn7);
            this.Controls.Add(this.btn6);
            this.Controls.Add(this.btn5);
            this.Controls.Add(this.btn4);
            this.Controls.Add(this.btn3);
            this.Controls.Add(this.btn2);
            this.Controls.Add(this.btn1);
            this.Controls.Add(this.Entry_txtbox);
            this.Controls.Add(this.lblID);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "MainForm_232911C";
            this.Text = "MainForm_232911C";
            this.Load += new System.EventHandler(this.MainForm_232911C_Load);
            this.KeyDown += new System.Windows.Forms.KeyEventHandler(this.BtnPress_Keydown);
            this.panelxtrabtns.ResumeLayout(false);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lblID;
        private System.Windows.Forms.TextBox Entry_txtbox;
        private System.Windows.Forms.Button btn1;
        private System.Windows.Forms.Button btn2;
        private System.Windows.Forms.Button btn3;
        private System.Windows.Forms.Button btn4;
        private System.Windows.Forms.Button btn5;
        private System.Windows.Forms.Button btn6;
        private System.Windows.Forms.Button btn7;
        private System.Windows.Forms.Button btn8;
        private System.Windows.Forms.Button btn9;
        private System.Windows.Forms.Button btn0;
        private System.Windows.Forms.Button btnDot;
        private System.Windows.Forms.Button btnAdd;
        private System.Windows.Forms.Button btnAC;
        private System.Windows.Forms.Button btnSqrt;
        private System.Windows.Forms.Button btnEqual;
        private System.Windows.Forms.Button btnSubtract;
        private System.Windows.Forms.Button btnSquare;
        private System.Windows.Forms.TextBox txtEntryAns;
        private System.Windows.Forms.Button btnMultiply;
        private System.Windows.Forms.Button btnDivide;
        private System.Windows.Forms.Button btnMod;
        private System.Windows.Forms.Button btnMode;
        private System.Windows.Forms.Button btnSinorLg;
        private System.Windows.Forms.Button btnCosorLn;
        private System.Windows.Forms.Button btnTanorex;
        private System.Windows.Forms.Button btnreciprocal;
        private System.Windows.Forms.Button btnsignflip;
        private System.Windows.Forms.Button btn10xorxa;
        private System.Windows.Forms.Button btnBackspace;
        private System.Windows.Forms.Button btnTrigLog;
        private System.Windows.Forms.Button btnDegRad;
        private System.Windows.Forms.Label lblDegRad;
        private System.Windows.Forms.CheckBox KBsoundchkbox;
        private System.Windows.Forms.CheckBox Speakerchkbox;
        private System.Windows.Forms.Panel panelxtrabtns;
        private System.Windows.Forms.Button btnsinh;
        private System.Windows.Forms.Button btncosh;
        private System.Windows.Forms.Button btntanh;
        private System.Windows.Forms.Button btnarcsin;
        private System.Windows.Forms.Button btnarctan;
        private System.Windows.Forms.Button btncopy;
    }
}

