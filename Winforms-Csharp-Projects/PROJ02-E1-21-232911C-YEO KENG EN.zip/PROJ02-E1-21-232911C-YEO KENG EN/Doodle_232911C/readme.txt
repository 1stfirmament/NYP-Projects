Project 2 Application Programming Enhancements 232911C

Enhancements:
Additional)

#Eyedropper Feature, press on the eyedropper picbox in the side panel, select your color and left click,this color is no your new selected color which u can use in brushMode/DrawingMode
#Color Dialog, Pick your color of your choice in drawingmode/brushmode
#Shape maker, for the shapemaker, drag and release for ellipse and rectangle and for polygon click on the points you want(max 12) and press enter to make the polygon you want.

#Fill bucket, right click on an enclosed region you want, pick your color on the sidepanel,and press the fill bucket picbox. By default,this fill bucket will fill outside of any enclosed area(if have) or the whole area with the selected color
#ColorFilter, To Filter Color Red,green or blue, pick the color of your own choice provided in the panel for transform/Filter, press the button and see the effects(The filters will overlay each other)

Innovative:
#Tooltip,custom tooltips hover to see
#Slider, for brush size,this is a user-friendly way to adjust the brush size dynamically.
#Light/DarkMode Feature,click on the sun or moon Logo to switch the color theme of the app

There are a total of 8 features in this Doodle Project of Yeo Keng En 232911C

