
Project 1 Application Programming Enhancements 232911C

Sources:

https://icon-icons.com/icon/business-calculator-ecommerce-finance-marketing-math-office/107525  -- calculator icon
https://mixkit.co/free-sound-effects/click/ -- gameclick_sound and gamecoinsound_click

Enhancements:
#Extra functions like sinh,arctan etc.
#A panel to hold the extra buttons
#On click button change color
#Other enhancements are listed in Project 1 
# have button sound 
# have result announcement asynchronous and at fast speed
# sound can be turn off and on 
#Copy button
#S keyboard and Shift S and Ctrl S does sqrt and square and Sin/Log unary operators respectively
#T ,shift T and ctrl T does tan, arctan and tanh respectively
#R keyboard does reciprocal





