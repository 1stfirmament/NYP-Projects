﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Globalization;
using System.Reflection;
using System.Runtime.InteropServices;
using System.Windows.Forms;
using System.Diagnostics.Eventing.Reader;
using System.Speech.Synthesis;
using System.Media;

namespace Calculator_232911C
{
    public partial class MainForm_232911C : Form
    {
        public MainForm_232911C()
        {
            InitializeComponent();
            KeyPreview = true; // Allows the form to receive key events before the controls
            
        }

        private void lblID_Click(object sender, EventArgs e)
        {
            Assembly assembly = Assembly.GetExecutingAssembly();
            var attribute = (GuidAttribute)assembly.GetCustomAttributes(typeof(GuidAttribute), true)[0];
            Clipboard.SetText(attribute.Value.ToString());
        }

        private void MainForm_232911C_Load(object sender, EventArgs e)
        {
            btnsinh.Hide();
            btncosh.Hide();
            btntanh.Hide();
            btnarcsin.Hide();
            btnarctan.Hide();
        }
        // Other form initialization and event handling code...

        // Functionality for handling keyboard sound checkbox change

        bool flagOpPressed = false;
        bool flagEquPressed = true;
        bool flagKBsound = false;
        bool flagSpeak = false;
        string eqn = "";
        SpeechSynthesizer syn = new SpeechSynthesizer();
        SoundPlayer KBplayer = new SoundPlayer("gamecoinsound_click.wav");//Sound wav file is in bin debug
        private void cbKBsound_CheckedChanged(object sender, EventArgs e)
        {
            if (KBsoundchkbox.Checked)
            {
                flagKBsound = true;// Flag to enable keyboard sound
            }
            else
            {
                flagKBsound = false;// Flag to disable keyboard sound
            }
            this.ActiveControl = null;// Reset the active control to none,lose focus on button
        }

        private void cbSpeaker_CheckChanged(object sender, EventArgs e)
        {
            if (Speakerchkbox.Checked)
            {
                flagSpeak = true;// Flag to enable speaking results
            }
            else
            {
                flagSpeak = false;// Flag to disable speaking results
            }
            this.ActiveControl = null;// Reset the active control to none,lose focus on button
        }




        // Functionality for handling numpad button click

        private void numPad_Click(object sender, EventArgs e)
        {
            Button btn = (Button)sender;
            string num = btn.Text;
            string temp = txtEntryAns.Text;
            

            if (flagOpPressed == true)
            {
                temp = "";
                flagOpPressed = false;
            }

            switch (num)
            {
                case ".":
                    if (!temp.Contains("."))
                    {
                        temp += ".";
                        eqn = Entry_txtbox.Text + num;//To debug ... error by ensuring that . is only added to eqn when it does not contain .
                    }
                    break;
                default:
                    if (temp == "0")
                        temp = "";
                    temp += num;
                    eqn = Entry_txtbox.Text + num; 
                    break;
            }
            txtEntryAns.Text = temp;
            Entry_txtbox.Text = eqn;
            btnEqual.Focus();
            
            if (flagKBsound == true)
            {
                KBplayer.Play(); //Play KB and click sound
            }
            else
            {

            }
            this.ActiveControl = null;
        }


        string opr = ""; 
        double operand = 0;
        double operand2 = 0;
        
        private void btnEqual_Click(object sender, EventArgs e)
        {


            operand2 = Double.Parse(txtEntryAns.Text);
            
            switch (opr) 
            {
                case "Add":
                    operand = operand + operand2;
                    txtEntryAns.Text = operand.ToString();

                    break;
                case "Minus":
                    operand = operand - operand2;
                    txtEntryAns.Text = operand.ToString();
                    break;
                case "Multiply":
                    operand = operand * operand2;
                    txtEntryAns.Text = operand.ToString();
                    break;
                case "Divide":
                    operand = operand / operand2;
                    txtEntryAns.Text = operand.ToString();
                    break;
                case "Mod":
                    operand = operand % operand2;
                    txtEntryAns.Text = operand.ToString();
                    break;
                default:
                    break; 
            }
            opr = "";
            btnEqual.Focus();
            if (flagSpeak == true)
            {
                if (!string.IsNullOrEmpty(Entry_txtbox.Text) && char.IsDigit(Entry_txtbox.Text.Last()) && flagEquPressed == true)
                {
                    syn.Rate = 3; // Set the rate before speaking
                    syn.SpeakAsync($"The computation is {txtEntryAns.Text}");
                }
            }
            else
            {

            }
            
            this.ActiveControl = null;
            flagEquPressed = true;

            if (flagKBsound == true)
            {
                KBplayer.Play();
            }
            else
            {

            }
        }




        private void operator_Click(object sender, EventArgs e)
        {

            Button btn = (Button)sender;
            
            if (flagOpPressed == false) // this skips the entire btnEqual.PerformClick() as to ensure no operator works when one operator is at end of string
               {
                flagEquPressed = false;
                btnEqual.PerformClick();
                    
               }

            operand = Double.Parse(txtEntryAns.Text);
            flagOpPressed = true;
            btnEqual.Focus(); //Focus on btnEqual() as to not allow Enter Key of affect this Code
            Entry_txtbox.Text = eqn + btn.Text;
            opr = btn.Tag.ToString();
            this.ActiveControl = null;

            if (flagKBsound == true)
            {
                KBplayer.Play();
            }
            else
            {

            }

        }
        private void btnAC_Click(object sender, EventArgs e)
        {
            opr = "";
            operand = 0;
            flagOpPressed = false;
            txtEntryAns.Text = "0";
            Entry_txtbox.Text = "";
            if (flagKBsound == true)
            {
                KBplayer.Play();
            }
            else
            {

            }
        }
        double pi = Math.PI;
        private void u_operator_Click(object sender, EventArgs e)
        {
            Button btn = (Button)sender;
            string u_opr = btn.Tag.ToString();
            string u_op = btn.Text.ToString();
            double value = Double.Parse(txtEntryAns.Text);
            
            eqn = u_op + "(" + value + ")";
            Entry_txtbox.Text = eqn;
            
            // this code is to print the functions and unary operations with the operand nicely
            if (eqn.Contains("x"))
            {
                eqn = "";
                eqn = "1/" + value;
                Entry_txtbox.Text = eqn;
            }
            else if (eqn.Contains("²")) 
            {
                eqn = "";
                eqn =  value + "²";
                Entry_txtbox.Text = eqn;
            }
            else if (eqn.Contains("10ˣ"))
            {
                eqn = "";
                eqn = "10^"+ value ;
                Entry_txtbox.Text = eqn;
            }
            else if (eqn.Contains("eˣ"))
            {
                eqn = "";
                eqn = "e^" + value;
                Entry_txtbox.Text = eqn;
            }
            
            
            string results;
            switch (u_opr)
            {
                case "Sqrt":
                    results = Math.Sqrt(value).ToString("N10");
                    txtEntryAns.Text = results.TrimEnd('0').TrimEnd('.');
                    break;
                case "Square":
                    results = Math.Pow(value, 2).ToString("N10");
                    txtEntryAns.Text = results.TrimEnd('0').TrimEnd('.');
                    break;
                case "Sign":
                    results = (-1 * value).ToString("N10"); ;
                    txtEntryAns.Text = results.TrimEnd('0').TrimEnd('.');
                    break;
                case "Reciprocal":
                    results = (1/value).ToString("N10"); ;
                    txtEntryAns.Text = results.TrimEnd('0').TrimEnd('.');
                    break;
                case "Sin":
                    if (DegRadSwitch == 0)
                    {
                        results = Math.Sin(value).ToString();
                        txtEntryAns.Text = results.TrimEnd('0').TrimEnd('.');
                    }
                    else if (DegRadSwitch == 1)
                    {
                        results = Math.Sin(value*(pi/180)).ToString();
                        txtEntryAns.Text = results.TrimEnd('0').TrimEnd('.');
                    }
                        break;
                case "Cos":
                    if (DegRadSwitch == 0)
                    {
                        results = Math.Cos(value).ToString();
                        txtEntryAns.Text = results.TrimEnd('0').TrimEnd('.');
                        
                    }
                    else if (DegRadSwitch == 1)
                    {
                        results = Math.Cos(value * (pi/180)).ToString();
                        txtEntryAns.Text = results.TrimEnd('0').TrimEnd('.');
                        
                    }
                    break;
                case "Tan":
                    if (DegRadSwitch == 0)
                    {
                        results = Math.Tan(value).ToString();
                        txtEntryAns.Text = results.TrimEnd('0').TrimEnd('.');
                    }
                    else if (DegRadSwitch == 1)
                    {
                        results = Math.Tan(value * (pi / 180)).ToString();
                        txtEntryAns.Text = results.TrimEnd('0').TrimEnd('.');
                    }
                    break;
                case "Lg":
                    results = Math.Log10(value).ToString();
                    txtEntryAns.Text = results.TrimEnd('0').TrimEnd('.');
                    break;
                case "Ln":
                    results = Math.Log(value).ToString();
                    txtEntryAns.Text = results.TrimEnd('0').TrimEnd('.');
                    break;
                case "ex":
                    results = Math.Exp(value).ToString();
                    txtEntryAns.Text = results.TrimEnd('0').TrimEnd('.');
                    break;
                case "10x":
                    results = Math.Pow(10,value).ToString();
                    txtEntryAns.Text = results.TrimEnd('0').TrimEnd('.');
                    break;
                case "sinh":
                    if (DegRadSwitch == 0)
                    {
                        results = Math.Sinh(value).ToString();
                        txtEntryAns.Text = results.TrimEnd('0').TrimEnd('.');
                    }
                    else if (DegRadSwitch == 1)
                    {
                        results = Math.Sinh(value * (pi / 180)).ToString();
                        txtEntryAns.Text = results.TrimEnd('0').TrimEnd('.');
                    }
                    break;
                case "cosh":
                    if (DegRadSwitch == 0)
                    {
                        results = Math.Cosh(value).ToString();
                        txtEntryAns.Text = results.TrimEnd('0').TrimEnd('.');
                    }
                    else if (DegRadSwitch == 1)
                    {
                        results = Math.Cosh(value * (pi / 180)).ToString();
                        txtEntryAns.Text = results.TrimEnd('0').TrimEnd('.');
                    }
                    break;
                case "tanh":
                    if (DegRadSwitch == 0)
                    {
                        results = Math.Tanh(value).ToString();
                        txtEntryAns.Text = results.TrimEnd('0').TrimEnd('.');
                    }
                    else if (DegRadSwitch == 1)
                    {
                        results = Math.Tanh(value * (pi / 180)).ToString();
                        txtEntryAns.Text = results.TrimEnd('0').TrimEnd('.');
                    }
                    break;
                case "arcsin":
                    if (eqn != "ArcSin(0)")
                    {
                        if (DegRadSwitch == 0)
                        {
                            results = Math.Asin(value).ToString();
                            txtEntryAns.Text = results.TrimEnd('0').TrimEnd('.');
                        }
                        else if (DegRadSwitch == 1)
                        {
                            results = Math.Asin(value * (pi / 180)).ToString();
                            txtEntryAns.Text = results.TrimEnd('0').TrimEnd('.');
                        }
                        
                    }
                    else
                    {
                        txtEntryAns.Text = "Math Error";
                        txtEntryAns.Font = AnotherSmallFont;
                    }
                    break;
                

                case "arctan":
                    if(eqn != "Arctan(0)") //Ensure code does not crash when answer is 0
                    {
                        if (DegRadSwitch == 0)
                        {
                            results = Math.Atan(value).ToString();
                            txtEntryAns.Text = results.TrimEnd('0').TrimEnd('.');

                        }
                        else if (DegRadSwitch == 1)
                        {
                            results = Math.Atan(value * (pi / 180)).ToString();
                            txtEntryAns.Text = results.TrimEnd('0').TrimEnd('.');
                        }
                    }
                    else
                    {
                        txtEntryAns.Text = "Math Error";
                        txtEntryAns.Font = AnotherSmallFont;
                    }
                    
                    break;



            }
            if (flagSpeak == true)
            {
                if (!string.IsNullOrEmpty(Entry_txtbox.Text))
                {

                    syn.Rate = 3; // Set the rate before speaking
                    syn.SpeakAsync($"The computation is {txtEntryAns.Text}");//Speak asynchronously as to allow input even when announcing 
                }
            }
            else
            {

            }
            if (eqn.Contains("±"))
            {
                eqn = txtEntryAns.Text;
                Entry_txtbox.Text = eqn;
            }
            
            
            if (flagKBsound == true)
            {
                KBplayer.Play();
            }
            else
            {

            }
            this.ActiveControl = null;
        }

        

        Font LargeFont = new Font("Arial", 14);
        Font SmallFont = new Font("Arial", 10); //declare different font size
        Font AnotherSmallFont = new Font("OCR A Extended", 20);

        int ModeSwitch = 0;
        
        private void btnMode_Click(object sender, EventArgs e)
        {
            

            switch (ModeSwitch) 
            { 
                case 0:
                    btn10xorxa.Tag = "10x";
                    btn10xorxa.Text = "10ˣ";
                    btnSinorLg.Tag = "Lg";
                    btnSinorLg.Text = "Log₁₀";
                    btnSinorLg.Font = SmallFont;
                    btnCosorLn.Tag = "Ln";
                    btnCosorLn.Text = "Ln";
                    btnTanorex.Tag = "ex";
                    btnTanorex.Font = LargeFont;
                    btnTanorex.Text = "eˣ";
                    btnSquare.Tag = "Square";
                    btnSquare.Text= "𝑥²";
                    btnSqrt.Tag = "Sqrt";
                    btnSqrt.Text = "√";
                    btnreciprocal.Tag = "Reciprocal";
                    btnreciprocal.Text = "1/x";
                    btnsignflip.Tag = "Sign";
                    btnsignflip.Text = "±";
                    btnMode.Text = "SCI";
                    ModeSwitch = 1;
                    // extra buttons
                    btnsinh.Text = "sinh";
                    btnsinh.Show();
                    btncosh.Text = "Cosh";
                    btncosh.Show();
                    btntanh.Text = "Tanh";
                    btntanh.Show();
                    btnarcsin.Text = "Arcsin";
                    btnarcsin.Show();
                    btnarctan.Text = "Arctan";
                    btnarctan.Show();
                    break;
                case 1:
                    btn10xorxa.Tag = "";
                    btn10xorxa.Text = "";
                    btnSinorLg.Tag = "";
                    btnSinorLg.Text = "";
                    btnCosorLn.Tag = "";
                    btnCosorLn.Text = "";
                    btnTanorex.Tag = "";
                    btnTanorex.Text = "";
                    btnSquare.Tag = "";
                    btnSquare.Text = "";
                    btnSqrt.Tag = "";
                    btnSqrt.Text = "";
                    btnreciprocal.Tag = "";
                    btnreciprocal.Text = "";
                    btnsignflip.Tag = "";
                    btnsignflip.Text = "";
                    btnMode.Text = "STD";
                    ModeSwitch = 0;
                    btnsinh.Hide();
                    btncosh.Hide();
                    btntanh.Hide();
                    btnarcsin.Hide();
                    btnarctan.Hide();
                    break;
                default:
                    break;

            }
            if (flagKBsound == true)
            {
                KBplayer.Play();
            }
            else
            {

            }
        }



        private void btnBackspace_Click(object sender, EventArgs e)
        {
            // Code to handle backspace button click...
            if (eqn != "") 
            {
                eqn = eqn.Remove(eqn.Length - 1);
                Entry_txtbox.Text = eqn;
                
            }
            if (eqn.Length == 0)
            {
                txtEntryAns.Text = "0";
            }

            if (flagKBsound == true)
            {
                KBplayer.Play();
            }
            else
            {

            }
        }


        int TrigLogSwitch = 0;
        private void btnTrigLog_Click(object sender, EventArgs e)
        {

            //Code to switch between trigonometric and logarithmic functions using switch case and a variable...
            if (ModeSwitch != 0)
            {
                switch (TrigLogSwitch)
                {
                    case 1:
                        btn10xorxa.Tag = "10x";
                        btn10xorxa.Text = "10ˣ";
                        btnSinorLg.Tag = "Lg";
                        btnSinorLg.Text = "Log₁₀";
                        btnSinorLg.Font = SmallFont;
                        btnCosorLn.Tag = "Ln";
                        btnCosorLn.Text = "Ln";
                        btnCosorLn.Font = LargeFont;
                        btnTanorex.Tag = "ex";
                        btnTanorex.Text = "eˣ";
                        btnTanorex.Font = LargeFont;
                        btnTrigLog.Text = "Trig";
                        TrigLogSwitch = 0;
                        break;
                    case 0:
                        btnSinorLg.Tag = "Sin";
                        btnSinorLg.Text = "Sin";
                        btnSinorLg.Font = SmallFont;
                        btnCosorLn.Tag = "Cos";
                        btnCosorLn.Font = SmallFont;
                        btnCosorLn.Text = "Cos";
                        btnTanorex.Font = SmallFont;
                        btnTanorex.Tag = "Tan";
                        btnTanorex.Text = "Tan";
                        btnTrigLog.Text = "Log";
                        TrigLogSwitch = 1;
                        break;
                    default:
                        break;

                }

                if (flagKBsound == true)
                {
                    KBplayer.Play();
                }
                else
                {

                }

            }
        }
        
        private void txtEntryAns_TextChanged(object sender, EventArgs e)
        {
            
            
        }
        int DegRadSwitch = 1;
        private void btnDegRad_Click(object sender, EventArgs e)
        {
            // Code to switch between degree and radian mode and also change the label...
            switch (DegRadSwitch)
            {
                case 0:
                    btnDegRad.Text = "Deg";
                    lblDegRad.Text = "Radian";
                    DegRadSwitch = 1;
                    
                    break;
                case 1:
                    btnDegRad.Text = "Rad";
                    lblDegRad.Text = "Degree";
                    DegRadSwitch = 0;
                    
                    break;
                default:


                    break;

            }
            if (flagKBsound == true)
            {
                KBplayer.Play();
            }
            else
            {

            }
        }

        private void BtnPress_Keydown(object sender, KeyEventArgs e)
        {
            // Code to handle keyboard keydown events...
            if (e.KeyCode == Keys.D0)
            {
                btn0.PerformClick();
            }
            if (e.KeyCode == Keys.D1)
            {
                btn1.PerformClick();
            }
            if (e.KeyCode == Keys.D2)
            {
                btn2.PerformClick();
            }
            if (e.KeyCode == Keys.D3)
            {
                btn3.PerformClick();
            }
            if (e.KeyCode == Keys.D4)
            {
                btn4.PerformClick();
            }
            
            if ((e.KeyCode == Keys.D5 && e.Shift))
            {
                btnMod.PerformClick();
            }
            else if (e.KeyCode == Keys.D5)
            {
                btn5.PerformClick();
            }
            if (e.KeyCode == Keys.D6)
            {
                btn6.PerformClick();
            }
            if (e.KeyCode == Keys.D7)
            {
                btn7.PerformClick();
            }
            
            if (e.KeyCode == Keys.D8 && e.Shift) //Shifts must be put before the normal keydown as to not activate 2 buttons
            {
                btnMultiply.PerformClick();
            }
            else if (e.KeyCode == Keys.D8)
            {
                btn8.PerformClick();
            }

            if (e.KeyCode == Keys.D9)
            {
                btn9.PerformClick();
            }
            if (e.KeyCode == Keys.Oemplus && e.Shift) /*OEM(Original Equipment Manufacturer)*/
            {
                btnAdd.PerformClick();
            }
            if (e.KeyCode == Keys.OemMinus)
            {
                btnSubtract.PerformClick();
            }
            
            if (e.KeyCode == Keys.Divide)
            {
                btnDivide.PerformClick();
            }
            
            if ((e.KeyCode == Keys.S && e.Shift && ModeSwitch == 1))
            {
                btnSquare.PerformClick();
                e.Handled = true;
            }
            else if (e.KeyCode == Keys.S && e.Control && ModeSwitch == 1)
            {
                btnSinorLg.PerformClick();
                e.Handled = true; // gets and sets the value when event is being handled
            }
            else if (e.KeyCode == Keys.S && ModeSwitch == 1)
            {
                btnSqrt.PerformClick();
                e.Handled = true;
            }
            else
            {

            }
            if ((e.KeyCode == Keys.T && e.Shift && ModeSwitch == 1))
            {
                btnarctan.PerformClick();
            }
            else if (e.KeyCode == Keys.T && e.Control && ModeSwitch == 1)
            {
                btntanh.PerformClick();
                e.Handled = true; // gets and sets the value when event is being handled
            }
            else if (e.KeyCode == Keys.T && ModeSwitch == 1) 
             {
                btnTanorex.PerformClick();
            }
            else
            {
                
            }
            if (e.KeyCode == Keys.R && ModeSwitch == 1)
            {
                btnreciprocal.PerformClick();
                e.Handled = true;
            }

            if (eqn != "") //ensure delete and enter does not delete or enter an empty string and break the code
            {
                if (e.KeyCode == Keys.Back)
                {
                    e.Handled = true;
                    if (e.Handled == true)
                    {
                        eqn = eqn.Remove(eqn.Length - 1);
                        Entry_txtbox.Text = eqn;
                    }
                }
                if (e.KeyCode == Keys.Enter)
                {
                    e.Handled = true;
                    btnEqual.PerformClick();
                }

            }
            if (eqn.Length == 0)
            {
                txtEntryAns.Text = "0";
            }

            if (flagKBsound == true)
            {
                KBplayer.Play();
            }
            else
            {

            }
            this.ActiveControl = null;
        }

        

        private void btncopy_click(object sender, EventArgs e)
        {
            Clipboard.SetText(txtEntryAns.Text);
        }
    }
    
    
}
