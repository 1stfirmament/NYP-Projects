﻿namespace Doodle_232911C
{
    partial class MainForm_232911C
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(MainForm_232911C));
            this.menuStrip1 = new System.Windows.Forms.MenuStrip();
            this.aboutToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.yeoKengEnToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.cToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.panelColor = new System.Windows.Forms.Panel();
            this.picBoxDropper = new System.Windows.Forms.PictureBox();
            this.picBoxChartreuse = new System.Windows.Forms.PictureBox();
            this.picBoxGold = new System.Windows.Forms.PictureBox();
            this.picBoxColorDialog = new System.Windows.Forms.PictureBox();
            this.picBoxMisc = new System.Windows.Forms.PictureBox();
            this.picBoxText = new System.Windows.Forms.PictureBox();
            this.picBoxOrange = new System.Windows.Forms.PictureBox();
            this.picBoxPink = new System.Windows.Forms.PictureBox();
            this.picBoxIndigo = new System.Windows.Forms.PictureBox();
            this.picBoxRed = new System.Windows.Forms.PictureBox();
            this.picBoxGreen = new System.Windows.Forms.PictureBox();
            this.picBoxBlue = new System.Windows.Forms.PictureBox();
            this.picBoxBlack = new System.Windows.Forms.PictureBox();
            this.picBoxBrushColor = new System.Windows.Forms.PictureBox();
            this.txtBoxText = new System.Windows.Forms.TextBox();
            this.comboBoxFonts = new System.Windows.Forms.ComboBox();
            this.labelTextInput = new System.Windows.Forms.Label();
            this.comboBoxFontSize = new System.Windows.Forms.ComboBox();
            this.labelFonts = new System.Windows.Forms.Label();
            this.labelFontSize = new System.Windows.Forms.Label();
            this.brushSizeTrackBar = new System.Windows.Forms.TrackBar();
            this.labelBrushSize = new System.Windows.Forms.Label();
            this.brushSizeNumber = new System.Windows.Forms.Label();
            this.toolTip = new System.Windows.Forms.ToolTip(this.components);
            this.comboBoxDrawShape = new System.Windows.Forms.ComboBox();
            this.picBoxLightDark = new System.Windows.Forms.PictureBox();
            this.picBox10E = new System.Windows.Forms.PictureBox();
            this.picBox50E = new System.Windows.Forms.PictureBox();
            this.picBox30E = new System.Windows.Forms.PictureBox();
            this.picBoxBlueFilter = new System.Windows.Forms.PictureBox();
            this.picBoxGreenFilter = new System.Windows.Forms.PictureBox();
            this.picBoxRedFilter = new System.Windows.Forms.PictureBox();
            this.picBoxFill = new System.Windows.Forms.PictureBox();
            this.pictBoxLoad = new System.Windows.Forms.PictureBox();
            this.picboxbrush = new System.Windows.Forms.PictureBox();
            this.picBoxErase = new System.Windows.Forms.PictureBox();
            this.picBoxClear = new System.Windows.Forms.PictureBox();
            this.picBoxSave = new System.Windows.Forms.PictureBox();
            this.panel1 = new System.Windows.Forms.Panel();
            this.btnTransform = new System.Windows.Forms.Button();
            this.panel2 = new System.Windows.Forms.Panel();
            this.TitleLabel = new System.Windows.Forms.Label();
            this.picBoxMain = new System.Windows.Forms.PictureBox();
            this.menuStrip1.SuspendLayout();
            this.panelColor.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.picBoxDropper)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.picBoxChartreuse)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.picBoxGold)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.picBoxColorDialog)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.picBoxMisc)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.picBoxText)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.picBoxOrange)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.picBoxPink)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.picBoxIndigo)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.picBoxRed)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.picBoxGreen)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.picBoxBlue)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.picBoxBlack)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.picBoxBrushColor)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.brushSizeTrackBar)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.picBoxLightDark)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.picBox10E)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.picBox50E)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.picBox30E)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.picBoxBlueFilter)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.picBoxGreenFilter)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.picBoxRedFilter)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.picBoxFill)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictBoxLoad)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.picboxbrush)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.picBoxErase)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.picBoxClear)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.picBoxSave)).BeginInit();
            this.panel1.SuspendLayout();
            this.panel2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.picBoxMain)).BeginInit();
            this.SuspendLayout();
            // 
            // menuStrip1
            // 
            this.menuStrip1.GripMargin = new System.Windows.Forms.Padding(2, 2, 0, 2);
            this.menuStrip1.ImageScalingSize = new System.Drawing.Size(24, 24);
            this.menuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.aboutToolStripMenuItem});
            this.menuStrip1.Location = new System.Drawing.Point(0, 0);
            this.menuStrip1.Name = "menuStrip1";
            this.menuStrip1.Size = new System.Drawing.Size(958, 33);
            this.menuStrip1.TabIndex = 0;
            this.menuStrip1.Text = "menuStrip1";
            // 
            // aboutToolStripMenuItem
            // 
            this.aboutToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.yeoKengEnToolStripMenuItem});
            this.aboutToolStripMenuItem.Name = "aboutToolStripMenuItem";
            this.aboutToolStripMenuItem.Size = new System.Drawing.Size(78, 29);
            this.aboutToolStripMenuItem.Text = "About";
            // 
            // yeoKengEnToolStripMenuItem
            // 
            this.yeoKengEnToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.cToolStripMenuItem});
            this.yeoKengEnToolStripMenuItem.Name = "yeoKengEnToolStripMenuItem";
            this.yeoKengEnToolStripMenuItem.Size = new System.Drawing.Size(211, 34);
            this.yeoKengEnToolStripMenuItem.Text = "Yeo Keng En";
            this.yeoKengEnToolStripMenuItem.Click += new System.EventHandler(this.yeoKengEnToolStripMenuItem_Click);
            // 
            // cToolStripMenuItem
            // 
            this.cToolStripMenuItem.Name = "cToolStripMenuItem";
            this.cToolStripMenuItem.Size = new System.Drawing.Size(185, 34);
            this.cToolStripMenuItem.Text = "232911C";
            // 
            // panelColor
            // 
            this.panelColor.Controls.Add(this.picBoxDropper);
            this.panelColor.Controls.Add(this.picBoxChartreuse);
            this.panelColor.Controls.Add(this.picBoxGold);
            this.panelColor.Controls.Add(this.picBoxColorDialog);
            this.panelColor.Controls.Add(this.picBoxMisc);
            this.panelColor.Controls.Add(this.picBoxText);
            this.panelColor.Controls.Add(this.picBoxOrange);
            this.panelColor.Controls.Add(this.picBoxPink);
            this.panelColor.Controls.Add(this.picBoxIndigo);
            this.panelColor.Controls.Add(this.picBoxRed);
            this.panelColor.Controls.Add(this.picBoxGreen);
            this.panelColor.Controls.Add(this.picBoxBlue);
            this.panelColor.Controls.Add(this.picBoxBlack);
            this.panelColor.Controls.Add(this.picBoxBrushColor);
            this.panelColor.Location = new System.Drawing.Point(852, 88);
            this.panelColor.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.panelColor.Name = "panelColor";
            this.panelColor.Size = new System.Drawing.Size(94, 408);
            this.panelColor.TabIndex = 11;
            // 
            // picBoxDropper
            // 
            this.picBoxDropper.Image = global::Doodle_232911C.Properties.Resources.EyeDropper;
            this.picBoxDropper.Location = new System.Drawing.Point(46, 357);
            this.picBoxDropper.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.picBoxDropper.Name = "picBoxDropper";
            this.picBoxDropper.Size = new System.Drawing.Size(42, 38);
            this.picBoxDropper.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.picBoxDropper.TabIndex = 23;
            this.picBoxDropper.TabStop = false;
            this.picBoxDropper.Tag = "Dropper";
            this.toolTip.SetToolTip(this.picBoxDropper, "Color Eyedropper");
            this.picBoxDropper.Click += new System.EventHandler(this.SelectColor_Click);
            // 
            // picBoxChartreuse
            // 
            this.picBoxChartreuse.BackColor = System.Drawing.Color.Chartreuse;
            this.picBoxChartreuse.Location = new System.Drawing.Point(4, 272);
            this.picBoxChartreuse.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.picBoxChartreuse.Name = "picBoxChartreuse";
            this.picBoxChartreuse.Size = new System.Drawing.Size(40, 38);
            this.picBoxChartreuse.TabIndex = 22;
            this.picBoxChartreuse.TabStop = false;
            this.picBoxChartreuse.Tag = "Chartreuse";
            this.toolTip.SetToolTip(this.picBoxChartreuse, "Chartreuse");
            this.picBoxChartreuse.Click += new System.EventHandler(this.SelectColor_Click);
            // 
            // picBoxGold
            // 
            this.picBoxGold.BackColor = System.Drawing.Color.Gold;
            this.picBoxGold.Location = new System.Drawing.Point(50, 228);
            this.picBoxGold.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.picBoxGold.Name = "picBoxGold";
            this.picBoxGold.Size = new System.Drawing.Size(40, 38);
            this.picBoxGold.TabIndex = 21;
            this.picBoxGold.TabStop = false;
            this.picBoxGold.Tag = "Gold";
            this.toolTip.SetToolTip(this.picBoxGold, "Gold");
            this.picBoxGold.Click += new System.EventHandler(this.SelectColor_Click);
            // 
            // picBoxColorDialog
            // 
            this.picBoxColorDialog.Image = global::Doodle_232911C.Properties.Resources.Palette;
            this.picBoxColorDialog.Location = new System.Drawing.Point(48, 315);
            this.picBoxColorDialog.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.picBoxColorDialog.Name = "picBoxColorDialog";
            this.picBoxColorDialog.Size = new System.Drawing.Size(40, 38);
            this.picBoxColorDialog.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.picBoxColorDialog.TabIndex = 13;
            this.picBoxColorDialog.TabStop = false;
            this.toolTip.SetToolTip(this.picBoxColorDialog, "Color Dialog");
            this.picBoxColorDialog.Click += new System.EventHandler(this.picBoxColorDialog_Click);
            // 
            // picBoxMisc
            // 
            this.picBoxMisc.BackColor = System.Drawing.Color.GhostWhite;
            this.picBoxMisc.Location = new System.Drawing.Point(50, 270);
            this.picBoxMisc.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.picBoxMisc.Name = "picBoxMisc";
            this.picBoxMisc.Size = new System.Drawing.Size(40, 38);
            this.picBoxMisc.TabIndex = 20;
            this.picBoxMisc.TabStop = false;
            this.picBoxMisc.Tag = "Misc";
            this.toolTip.SetToolTip(this.picBoxMisc, "Custom");
            this.picBoxMisc.Click += new System.EventHandler(this.SelectColor_Click);
            // 
            // picBoxText
            // 
            this.picBoxText.Image = global::Doodle_232911C.Properties.Resources.text;
            this.picBoxText.Location = new System.Drawing.Point(3, 315);
            this.picBoxText.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.picBoxText.Name = "picBoxText";
            this.picBoxText.Size = new System.Drawing.Size(42, 38);
            this.picBoxText.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.picBoxText.TabIndex = 10;
            this.picBoxText.TabStop = false;
            this.toolTip.SetToolTip(this.picBoxText, "Text Mode");
            this.picBoxText.Click += new System.EventHandler(this.picBoxText_Click);
            // 
            // picBoxOrange
            // 
            this.picBoxOrange.BackColor = System.Drawing.Color.Orange;
            this.picBoxOrange.Location = new System.Drawing.Point(3, 141);
            this.picBoxOrange.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.picBoxOrange.Name = "picBoxOrange";
            this.picBoxOrange.Size = new System.Drawing.Size(40, 38);
            this.picBoxOrange.TabIndex = 19;
            this.picBoxOrange.TabStop = false;
            this.picBoxOrange.Tag = "Orange";
            this.toolTip.SetToolTip(this.picBoxOrange, "Orange");
            this.picBoxOrange.Click += new System.EventHandler(this.SelectColor_Click);
            // 
            // picBoxPink
            // 
            this.picBoxPink.BackColor = System.Drawing.Color.Pink;
            this.picBoxPink.Location = new System.Drawing.Point(50, 141);
            this.picBoxPink.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.picBoxPink.Name = "picBoxPink";
            this.picBoxPink.Size = new System.Drawing.Size(40, 38);
            this.picBoxPink.TabIndex = 18;
            this.picBoxPink.TabStop = false;
            this.picBoxPink.Tag = "Pink";
            this.toolTip.SetToolTip(this.picBoxPink, "Pink");
            this.picBoxPink.Click += new System.EventHandler(this.SelectColor_Click);
            // 
            // picBoxIndigo
            // 
            this.picBoxIndigo.BackColor = System.Drawing.Color.Indigo;
            this.picBoxIndigo.Location = new System.Drawing.Point(3, 228);
            this.picBoxIndigo.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.picBoxIndigo.Name = "picBoxIndigo";
            this.picBoxIndigo.Size = new System.Drawing.Size(40, 38);
            this.picBoxIndigo.TabIndex = 17;
            this.picBoxIndigo.TabStop = false;
            this.picBoxIndigo.Tag = "Indigo";
            this.toolTip.SetToolTip(this.picBoxIndigo, "Indigo");
            this.picBoxIndigo.Click += new System.EventHandler(this.SelectColor_Click);
            // 
            // picBoxRed
            // 
            this.picBoxRed.BackColor = System.Drawing.Color.Red;
            this.picBoxRed.Location = new System.Drawing.Point(50, 184);
            this.picBoxRed.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.picBoxRed.Name = "picBoxRed";
            this.picBoxRed.Size = new System.Drawing.Size(40, 38);
            this.picBoxRed.TabIndex = 16;
            this.picBoxRed.TabStop = false;
            this.picBoxRed.Tag = "Red";
            this.toolTip.SetToolTip(this.picBoxRed, "Red");
            this.picBoxRed.Click += new System.EventHandler(this.SelectColor_Click);
            // 
            // picBoxGreen
            // 
            this.picBoxGreen.BackColor = System.Drawing.Color.Green;
            this.picBoxGreen.Location = new System.Drawing.Point(3, 184);
            this.picBoxGreen.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.picBoxGreen.Name = "picBoxGreen";
            this.picBoxGreen.Size = new System.Drawing.Size(40, 38);
            this.picBoxGreen.TabIndex = 15;
            this.picBoxGreen.TabStop = false;
            this.picBoxGreen.Tag = "Green";
            this.toolTip.SetToolTip(this.picBoxGreen, "Green");
            this.picBoxGreen.Click += new System.EventHandler(this.SelectColor_Click);
            // 
            // picBoxBlue
            // 
            this.picBoxBlue.BackColor = System.Drawing.Color.Blue;
            this.picBoxBlue.Location = new System.Drawing.Point(50, 98);
            this.picBoxBlue.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.picBoxBlue.Name = "picBoxBlue";
            this.picBoxBlue.Size = new System.Drawing.Size(40, 38);
            this.picBoxBlue.TabIndex = 14;
            this.picBoxBlue.TabStop = false;
            this.picBoxBlue.Tag = "Blue";
            this.toolTip.SetToolTip(this.picBoxBlue, "Blue");
            this.picBoxBlue.Click += new System.EventHandler(this.SelectColor_Click);
            // 
            // picBoxBlack
            // 
            this.picBoxBlack.BackColor = System.Drawing.Color.Black;
            this.picBoxBlack.Location = new System.Drawing.Point(3, 98);
            this.picBoxBlack.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.picBoxBlack.Name = "picBoxBlack";
            this.picBoxBlack.Size = new System.Drawing.Size(40, 38);
            this.picBoxBlack.TabIndex = 13;
            this.picBoxBlack.TabStop = false;
            this.picBoxBlack.Tag = "Black";
            this.toolTip.SetToolTip(this.picBoxBlack, "Black");
            this.picBoxBlack.Click += new System.EventHandler(this.SelectColor_Click);
            // 
            // picBoxBrushColor
            // 
            this.picBoxBrushColor.BackColor = System.Drawing.Color.Black;
            this.picBoxBrushColor.Location = new System.Drawing.Point(3, 4);
            this.picBoxBrushColor.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.picBoxBrushColor.Name = "picBoxBrushColor";
            this.picBoxBrushColor.Size = new System.Drawing.Size(86, 88);
            this.picBoxBrushColor.TabIndex = 12;
            this.picBoxBrushColor.TabStop = false;
            this.toolTip.SetToolTip(this.picBoxBrushColor, "Color Selected");
            // 
            // txtBoxText
            // 
            this.txtBoxText.Location = new System.Drawing.Point(510, 538);
            this.txtBoxText.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.txtBoxText.Name = "txtBoxText";
            this.txtBoxText.Size = new System.Drawing.Size(336, 26);
            this.txtBoxText.TabIndex = 12;
            this.txtBoxText.Text = "Misc";
            this.toolTip.SetToolTip(this.txtBoxText, "Enter You Text...");
            // 
            // comboBoxFonts
            // 
            this.comboBoxFonts.DropDownHeight = 80;
            this.comboBoxFonts.DropDownWidth = 30;
            this.comboBoxFonts.FormattingEnabled = true;
            this.comboBoxFonts.IntegralHeight = false;
            this.comboBoxFonts.Location = new System.Drawing.Point(461, 582);
            this.comboBoxFonts.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.comboBoxFonts.Name = "comboBoxFonts";
            this.comboBoxFonts.Size = new System.Drawing.Size(113, 28);
            this.comboBoxFonts.TabIndex = 14;
            this.toolTip.SetToolTip(this.comboBoxFonts, "Choose your fonts");
            this.comboBoxFonts.SelectedIndexChanged += new System.EventHandler(this.comboBoxFonts_SelectedIndexChanged);
            // 
            // labelTextInput
            // 
            this.labelTextInput.AutoSize = true;
            this.labelTextInput.Location = new System.Drawing.Point(374, 542);
            this.labelTextInput.Name = "labelTextInput";
            this.labelTextInput.Size = new System.Drawing.Size(116, 20);
            this.labelTextInput.TabIndex = 15;
            this.labelTextInput.Text = "Enter your text:";
            // 
            // comboBoxFontSize
            // 
            this.comboBoxFontSize.DropDownHeight = 80;
            this.comboBoxFontSize.DropDownWidth = 30;
            this.comboBoxFontSize.FormattingEnabled = true;
            this.comboBoxFontSize.IntegralHeight = false;
            this.comboBoxFontSize.Items.AddRange(new object[] {
            "2",
            "3",
            "5",
            "7",
            "10",
            "11",
            "13",
            "15",
            "17",
            "19",
            "20",
            "23",
            "25",
            "29",
            "30",
            "31",
            "35",
            "37",
            "40",
            "41",
            "43",
            "45",
            "47",
            "50",
            "53",
            "55",
            "59",
            "60"});
            this.comboBoxFontSize.Location = new System.Drawing.Point(687, 586);
            this.comboBoxFontSize.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.comboBoxFontSize.Name = "comboBoxFontSize";
            this.comboBoxFontSize.Size = new System.Drawing.Size(113, 28);
            this.comboBoxFontSize.TabIndex = 16;
            this.toolTip.SetToolTip(this.comboBoxFontSize, "Choose your font size");
            this.comboBoxFontSize.SelectedIndexChanged += new System.EventHandler(this.comboBoxFontSize_SelectedIndexChanged);
            // 
            // labelFonts
            // 
            this.labelFonts.AutoSize = true;
            this.labelFonts.Location = new System.Drawing.Point(400, 586);
            this.labelFonts.Name = "labelFonts";
            this.labelFonts.Size = new System.Drawing.Size(54, 20);
            this.labelFonts.TabIndex = 17;
            this.labelFonts.Text = "Fonts:";
            // 
            // labelFontSize
            // 
            this.labelFontSize.AutoSize = true;
            this.labelFontSize.Location = new System.Drawing.Point(600, 586);
            this.labelFontSize.Name = "labelFontSize";
            this.labelFontSize.Size = new System.Drawing.Size(81, 20);
            this.labelFontSize.TabIndex = 18;
            this.labelFontSize.Text = "Font Size:";
            // 
            // brushSizeTrackBar
            // 
            this.brushSizeTrackBar.LargeChange = 1;
            this.brushSizeTrackBar.Location = new System.Drawing.Point(0, 116);
            this.brushSizeTrackBar.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.brushSizeTrackBar.Maximum = 50;
            this.brushSizeTrackBar.Minimum = 5;
            this.brushSizeTrackBar.Name = "brushSizeTrackBar";
            this.brushSizeTrackBar.Orientation = System.Windows.Forms.Orientation.Vertical;
            this.brushSizeTrackBar.Size = new System.Drawing.Size(69, 418);
            this.brushSizeTrackBar.TabIndex = 21;
            this.toolTip.SetToolTip(this.brushSizeTrackBar, "Brush Sizing");
            this.brushSizeTrackBar.Value = 5;
            this.brushSizeTrackBar.Scroll += new System.EventHandler(this.brushSizeTrackBar_Scroll);
            // 
            // labelBrushSize
            // 
            this.labelBrushSize.AutoSize = true;
            this.labelBrushSize.Location = new System.Drawing.Point(-4, 92);
            this.labelBrushSize.Name = "labelBrushSize";
            this.labelBrushSize.Size = new System.Drawing.Size(90, 20);
            this.labelBrushSize.TabIndex = 22;
            this.labelBrushSize.Text = "Brush Size:";
            // 
            // brushSizeNumber
            // 
            this.brushSizeNumber.AutoSize = true;
            this.brushSizeNumber.Location = new System.Drawing.Point(8, 538);
            this.brushSizeNumber.Name = "brushSizeNumber";
            this.brushSizeNumber.Size = new System.Drawing.Size(27, 20);
            this.brushSizeNumber.TabIndex = 23;
            this.brushSizeNumber.Text = "15";
            // 
            // toolTip
            // 
            this.toolTip.AutoPopDelay = 500000000;
            this.toolTip.InitialDelay = 5;
            this.toolTip.ReshowDelay = 100;
            // 
            // comboBoxDrawShape
            // 
            this.comboBoxDrawShape.DropDownHeight = 80;
            this.comboBoxDrawShape.FormattingEnabled = true;
            this.comboBoxDrawShape.IntegralHeight = false;
            this.comboBoxDrawShape.Items.AddRange(new object[] {
            "Rectangle",
            "Ellipse",
            "Polygon"});
            this.comboBoxDrawShape.Location = new System.Drawing.Point(538, 44);
            this.comboBoxDrawShape.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.comboBoxDrawShape.Name = "comboBoxDrawShape";
            this.comboBoxDrawShape.Size = new System.Drawing.Size(121, 28);
            this.comboBoxDrawShape.TabIndex = 25;
            this.toolTip.SetToolTip(this.comboBoxDrawShape, "Drag and drop your own shape");
            this.comboBoxDrawShape.SelectedIndexChanged += new System.EventHandler(this.comboBoxDrawShape_SelectedIndexChanged);
            // 
            // picBoxLightDark
            // 
            this.picBoxLightDark.Image = global::Doodle_232911C.Properties.Resources.Dark;
            this.picBoxLightDark.Location = new System.Drawing.Point(677, 36);
            this.picBoxLightDark.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.picBoxLightDark.Name = "picBoxLightDark";
            this.picBoxLightDark.Size = new System.Drawing.Size(48, 45);
            this.picBoxLightDark.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.picBoxLightDark.TabIndex = 30;
            this.picBoxLightDark.TabStop = false;
            this.toolTip.SetToolTip(this.picBoxLightDark, "Light/DarkMode");
            this.picBoxLightDark.Click += new System.EventHandler(this.picBoxLightDark_Click);
            // 
            // picBox10E
            // 
            this.picBox10E.BackColor = System.Drawing.Color.SlateGray;
            this.picBox10E.Location = new System.Drawing.Point(42, 0);
            this.picBox10E.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.picBox10E.Name = "picBox10E";
            this.picBox10E.Size = new System.Drawing.Size(26, 23);
            this.picBox10E.TabIndex = 27;
            this.picBox10E.TabStop = false;
            this.picBox10E.Tag = "10";
            this.toolTip.SetToolTip(this.picBox10E, "10pts");
            this.picBox10E.Click += new System.EventHandler(this.erasorSize_Click);
            // 
            // picBox50E
            // 
            this.picBox50E.BackColor = System.Drawing.Color.SlateGray;
            this.picBox50E.Location = new System.Drawing.Point(3, 69);
            this.picBox50E.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.picBox50E.Name = "picBox50E";
            this.picBox50E.Size = new System.Drawing.Size(73, 28);
            this.picBox50E.TabIndex = 26;
            this.picBox50E.TabStop = false;
            this.picBox50E.Tag = "50";
            this.toolTip.SetToolTip(this.picBox50E, "50pts");
            this.picBox50E.Click += new System.EventHandler(this.erasorSize_Click);
            // 
            // picBox30E
            // 
            this.picBox30E.BackColor = System.Drawing.Color.SlateGray;
            this.picBox30E.Location = new System.Drawing.Point(31, 33);
            this.picBox30E.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.picBox30E.Name = "picBox30E";
            this.picBox30E.Size = new System.Drawing.Size(41, 26);
            this.picBox30E.TabIndex = 25;
            this.picBox30E.TabStop = false;
            this.picBox30E.Tag = "30";
            this.toolTip.SetToolTip(this.picBox30E, "30pts");
            this.picBox30E.Click += new System.EventHandler(this.erasorSize_Click);
            // 
            // picBoxBlueFilter
            // 
            this.picBoxBlueFilter.BackColor = System.Drawing.Color.Blue;
            this.picBoxBlueFilter.Location = new System.Drawing.Point(138, 5);
            this.picBoxBlueFilter.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.picBoxBlueFilter.Name = "picBoxBlueFilter";
            this.picBoxBlueFilter.Size = new System.Drawing.Size(40, 38);
            this.picBoxBlueFilter.TabIndex = 23;
            this.picBoxBlueFilter.TabStop = false;
            this.picBoxBlueFilter.Tag = "BlueF";
            this.toolTip.SetToolTip(this.picBoxBlueFilter, "Blue Filter");
            this.picBoxBlueFilter.Click += new System.EventHandler(this.SelectColorFilter_Click);
            // 
            // picBoxGreenFilter
            // 
            this.picBoxGreenFilter.BackColor = System.Drawing.Color.Chartreuse;
            this.picBoxGreenFilter.Location = new System.Drawing.Point(72, 5);
            this.picBoxGreenFilter.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.picBoxGreenFilter.Name = "picBoxGreenFilter";
            this.picBoxGreenFilter.Size = new System.Drawing.Size(40, 38);
            this.picBoxGreenFilter.TabIndex = 23;
            this.picBoxGreenFilter.TabStop = false;
            this.picBoxGreenFilter.Tag = "ChartreuseF";
            this.toolTip.SetToolTip(this.picBoxGreenFilter, "Chartreuse Filter");
            this.picBoxGreenFilter.Click += new System.EventHandler(this.SelectColorFilter_Click);
            // 
            // picBoxRedFilter
            // 
            this.picBoxRedFilter.BackColor = System.Drawing.Color.Red;
            this.picBoxRedFilter.Location = new System.Drawing.Point(8, 4);
            this.picBoxRedFilter.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.picBoxRedFilter.Name = "picBoxRedFilter";
            this.picBoxRedFilter.Size = new System.Drawing.Size(40, 38);
            this.picBoxRedFilter.TabIndex = 23;
            this.picBoxRedFilter.TabStop = false;
            this.picBoxRedFilter.Tag = "RedF";
            this.toolTip.SetToolTip(this.picBoxRedFilter, "Red Filter");
            this.picBoxRedFilter.Click += new System.EventHandler(this.SelectColorFilter_Click);
            // 
            // picBoxFill
            // 
            this.picBoxFill.Image = global::Doodle_232911C.Properties.Resources.fill;
            this.picBoxFill.Location = new System.Drawing.Point(731, 36);
            this.picBoxFill.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.picBoxFill.Name = "picBoxFill";
            this.picBoxFill.Size = new System.Drawing.Size(48, 45);
            this.picBoxFill.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.picBoxFill.TabIndex = 26;
            this.picBoxFill.TabStop = false;
            this.toolTip.SetToolTip(this.picBoxFill, "Fill Area");
            this.picBoxFill.Click += new System.EventHandler(this.picBoxFill_Click);
            // 
            // pictBoxLoad
            // 
            this.pictBoxLoad.Image = global::Doodle_232911C.Properties.Resources.Load;
            this.pictBoxLoad.Location = new System.Drawing.Point(78, 36);
            this.pictBoxLoad.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.pictBoxLoad.Name = "pictBoxLoad";
            this.pictBoxLoad.Size = new System.Drawing.Size(48, 45);
            this.pictBoxLoad.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictBoxLoad.TabIndex = 24;
            this.pictBoxLoad.TabStop = false;
            this.toolTip.SetToolTip(this.pictBoxLoad, "Load Image");
            this.pictBoxLoad.Click += new System.EventHandler(this.pictBoxLoad_Click);
            // 
            // picboxbrush
            // 
            this.picboxbrush.Image = global::Doodle_232911C.Properties.Resources.Brush;
            this.picboxbrush.Location = new System.Drawing.Point(785, 36);
            this.picboxbrush.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.picboxbrush.Name = "picboxbrush";
            this.picboxbrush.Size = new System.Drawing.Size(48, 45);
            this.picboxbrush.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.picboxbrush.TabIndex = 9;
            this.picboxbrush.TabStop = false;
            this.toolTip.SetToolTip(this.picboxbrush, "Brush Mode");
            this.picboxbrush.Click += new System.EventHandler(this.picboxbrush_Click);
            // 
            // picBoxErase
            // 
            this.picBoxErase.Image = global::Doodle_232911C.Properties.Resources.erasor;
            this.picBoxErase.Location = new System.Drawing.Point(839, 36);
            this.picBoxErase.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.picBoxErase.Name = "picBoxErase";
            this.picBoxErase.Size = new System.Drawing.Size(48, 45);
            this.picBoxErase.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.picBoxErase.TabIndex = 8;
            this.picBoxErase.TabStop = false;
            this.toolTip.SetToolTip(this.picBoxErase, "Erase");
            this.picBoxErase.Click += new System.EventHandler(this.picBoxErase_Click);
            // 
            // picBoxClear
            // 
            this.picBoxClear.Image = global::Doodle_232911C.Properties.Resources.clear;
            this.picBoxClear.Location = new System.Drawing.Point(893, 36);
            this.picBoxClear.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.picBoxClear.Name = "picBoxClear";
            this.picBoxClear.Size = new System.Drawing.Size(48, 45);
            this.picBoxClear.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.picBoxClear.TabIndex = 7;
            this.picBoxClear.TabStop = false;
            this.toolTip.SetToolTip(this.picBoxClear, "Clear all");
            this.picBoxClear.Click += new System.EventHandler(this.picBoxClear_Click);
            // 
            // picBoxSave
            // 
            this.picBoxSave.Image = global::Doodle_232911C.Properties.Resources.save;
            this.picBoxSave.Location = new System.Drawing.Point(12, 36);
            this.picBoxSave.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.picBoxSave.Name = "picBoxSave";
            this.picBoxSave.Size = new System.Drawing.Size(48, 45);
            this.picBoxSave.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.picBoxSave.TabIndex = 4;
            this.picBoxSave.TabStop = false;
            this.toolTip.SetToolTip(this.picBoxSave, "Save");
            this.picBoxSave.Click += new System.EventHandler(this.picBoxSave_Click);
            // 
            // panel1
            // 
            this.panel1.Controls.Add(this.btnTransform);
            this.panel1.Controls.Add(this.picBoxBlueFilter);
            this.panel1.Controls.Add(this.picBoxGreenFilter);
            this.panel1.Controls.Add(this.picBoxRedFilter);
            this.panel1.Location = new System.Drawing.Point(78, 538);
            this.panel1.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(200, 100);
            this.panel1.TabIndex = 27;
            // 
            // btnTransform
            // 
            this.btnTransform.Location = new System.Drawing.Point(0, 48);
            this.btnTransform.Name = "btnTransform";
            this.btnTransform.Size = new System.Drawing.Size(178, 36);
            this.btnTransform.TabIndex = 25;
            this.btnTransform.Text = "Transform/Filter";
            this.btnTransform.UseVisualStyleBackColor = true;
            this.btnTransform.Click += new System.EventHandler(this.btnTransform_Click);
            // 
            // panel2
            // 
            this.panel2.Controls.Add(this.picBox10E);
            this.panel2.Controls.Add(this.picBox50E);
            this.panel2.Controls.Add(this.picBox30E);
            this.panel2.Location = new System.Drawing.Point(874, 509);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(84, 107);
            this.panel2.TabIndex = 28;
            this.panel2.Tag = "Erasor size";
            // 
            // TitleLabel
            // 
            this.TitleLabel.AutoSize = true;
            this.TitleLabel.Font = new System.Drawing.Font("Segoe UI Emoji", 15F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.TitleLabel.Location = new System.Drawing.Point(179, 36);
            this.TitleLabel.Name = "TitleLabel";
            this.TitleLabel.Size = new System.Drawing.Size(315, 40);
            this.TitleLabel.TabIndex = 29;
            this.TitleLabel.Text = "MyDoodleProject 😁";
            // 
            // picBoxMain
            // 
            this.picBoxMain.BackColor = System.Drawing.Color.GhostWhite;
            this.picBoxMain.Location = new System.Drawing.Point(87, 90);
            this.picBoxMain.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.picBoxMain.Name = "picBoxMain";
            this.picBoxMain.Size = new System.Drawing.Size(762, 444);
            this.picBoxMain.TabIndex = 2;
            this.picBoxMain.TabStop = false;
            this.picBoxMain.Paint += new System.Windows.Forms.PaintEventHandler(this.picBoxMain_Paint);
            this.picBoxMain.MouseDown += new System.Windows.Forms.MouseEventHandler(this.picBoxMain_MouseDown);
            this.picBoxMain.MouseMove += new System.Windows.Forms.MouseEventHandler(this.picBoxMain_MouseMove);
            this.picBoxMain.MouseUp += new System.Windows.Forms.MouseEventHandler(this.picBoxMain_MouseUp);
            // 
            // MainForm_232911C
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(958, 628);
            this.Controls.Add(this.picBoxLightDark);
            this.Controls.Add(this.TitleLabel);
            this.Controls.Add(this.panel2);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.picBoxFill);
            this.Controls.Add(this.comboBoxDrawShape);
            this.Controls.Add(this.pictBoxLoad);
            this.Controls.Add(this.brushSizeNumber);
            this.Controls.Add(this.labelBrushSize);
            this.Controls.Add(this.brushSizeTrackBar);
            this.Controls.Add(this.labelFontSize);
            this.Controls.Add(this.labelFonts);
            this.Controls.Add(this.comboBoxFontSize);
            this.Controls.Add(this.labelTextInput);
            this.Controls.Add(this.comboBoxFonts);
            this.Controls.Add(this.txtBoxText);
            this.Controls.Add(this.panelColor);
            this.Controls.Add(this.picboxbrush);
            this.Controls.Add(this.picBoxErase);
            this.Controls.Add(this.picBoxClear);
            this.Controls.Add(this.picBoxSave);
            this.Controls.Add(this.picBoxMain);
            this.Controls.Add(this.menuStrip1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.KeyPreview = true;
            this.MainMenuStrip = this.menuStrip1;
            this.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.Name = "MainForm_232911C";
            this.Text = " ";
            this.TopMost = true;
            this.Load += new System.EventHandler(this.MainForm_232911C_Load);
            this.KeyDown += new System.Windows.Forms.KeyEventHandler(this.ChangePen_KeyDown);
            this.KeyUp += new System.Windows.Forms.KeyEventHandler(this.ChangeBrush_KeyUp);
            this.menuStrip1.ResumeLayout(false);
            this.menuStrip1.PerformLayout();
            this.panelColor.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.picBoxDropper)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.picBoxChartreuse)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.picBoxGold)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.picBoxColorDialog)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.picBoxMisc)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.picBoxText)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.picBoxOrange)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.picBoxPink)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.picBoxIndigo)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.picBoxRed)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.picBoxGreen)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.picBoxBlue)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.picBoxBlack)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.picBoxBrushColor)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.brushSizeTrackBar)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.picBoxLightDark)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.picBox10E)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.picBox50E)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.picBox30E)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.picBoxBlueFilter)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.picBoxGreenFilter)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.picBoxRedFilter)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.picBoxFill)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictBoxLoad)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.picboxbrush)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.picBoxErase)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.picBoxClear)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.picBoxSave)).EndInit();
            this.panel1.ResumeLayout(false);
            this.panel2.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.picBoxMain)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.MenuStrip menuStrip1;
        private System.Windows.Forms.ToolStripMenuItem aboutToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem yeoKengEnToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem cToolStripMenuItem;
        private System.Windows.Forms.PictureBox picBoxMain;
        private System.Windows.Forms.PictureBox picBoxSave;
        private System.Windows.Forms.PictureBox picBoxClear;
        private System.Windows.Forms.PictureBox picBoxErase;
        private System.Windows.Forms.PictureBox picboxbrush;
        private System.Windows.Forms.PictureBox picBoxText;
        private System.Windows.Forms.Panel panelColor;
        private System.Windows.Forms.PictureBox picBoxIndigo;
        private System.Windows.Forms.PictureBox picBoxRed;
        private System.Windows.Forms.PictureBox picBoxGreen;
        private System.Windows.Forms.PictureBox picBoxBlue;
        private System.Windows.Forms.PictureBox picBoxBlack;
        private System.Windows.Forms.PictureBox picBoxBrushColor;
        private System.Windows.Forms.PictureBox picBoxChartreuse;
        private System.Windows.Forms.PictureBox picBoxGold;
        private System.Windows.Forms.PictureBox picBoxMisc;
        private System.Windows.Forms.PictureBox picBoxOrange;
        private System.Windows.Forms.PictureBox picBoxPink;
        private System.Windows.Forms.TextBox txtBoxText;
        private System.Windows.Forms.PictureBox picBoxColorDialog;
        private System.Windows.Forms.ComboBox comboBoxFonts;
        private System.Windows.Forms.Label labelTextInput;
        private System.Windows.Forms.ComboBox comboBoxFontSize;
        private System.Windows.Forms.Label labelFonts;
        private System.Windows.Forms.Label labelFontSize;
        private System.Windows.Forms.TrackBar brushSizeTrackBar;
        private System.Windows.Forms.Label labelBrushSize;
        private System.Windows.Forms.Label brushSizeNumber;
        private System.Windows.Forms.ToolTip toolTip;
        private System.Windows.Forms.PictureBox pictBoxLoad;
        private System.Windows.Forms.ComboBox comboBoxDrawShape;
        private System.Windows.Forms.PictureBox picBoxFill;
        private System.Windows.Forms.PictureBox picBoxRedFilter;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.PictureBox picBoxBlueFilter;
        private System.Windows.Forms.PictureBox picBoxGreenFilter;
        private System.Windows.Forms.Button btnTransform;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.PictureBox picBox10E;
        private System.Windows.Forms.PictureBox picBox50E;
        private System.Windows.Forms.PictureBox picBox30E;
        private System.Windows.Forms.Label TitleLabel;
        private System.Windows.Forms.PictureBox picBoxLightDark;
        private System.Windows.Forms.PictureBox picBoxDropper;
    }
}

