﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Drawing.Imaging;
using System.Drawing.Text;
using System.Linq;
using System.Reflection;
using System.Runtime.InteropServices;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Doodle_232911C
{
    public partial class MainForm_232911C : Form
    {

        Bitmap bm;
        Graphics g;
        Pen pen = new Pen(Color.Black, 5);
        SolidBrush brush = new SolidBrush(Color.Black);
        Point startP = new Point(0, 0);
        Point shapestartP = new Point(0, 0);
        Point endP = new Point(0, 0);

        string selectedFont;
        int selectedFontSize = 17;
        bool flagDraw = false;
        bool flagErase = false;
        bool flagText = false;
        string flagDrawingTool = "brush";
        Color TextColor = Color.Black;
        int brushSize = 15;
        bool flagLoaded = false;
        bool isDrawingPolygon = false; // Track if we're in polygon drawing mode
        int erasorSize = 30;
        bool bgMode = true;
        bool isDropperSelected = false;
        Point fillStartPoint;
        List<Point> polygonPoints = new List<Point>(); // Store points for polygon
        int maxPolygonSides = 12;


        bool flagDrawEnabled = false;
        string strText;
        string drawshape;

        public MainForm_232911C()
        {
            InitializeComponent();
        }

        private void MainForm_232911C_Load(object sender, EventArgs e)
        {


            brushSizeTrackBar.Value = 15;
            bm = new Bitmap(picBoxMain.Width, picBoxMain.Height);
            picBoxMain.Image = bm;
            g = Graphics.FromImage(bm);
            Rectangle rect = picBoxMain.ClientRectangle;
            g.FillRectangle(new SolidBrush(Color.GhostWhite), rect);
            g.Dispose();
            picBoxMain.Invalidate();
            // Loop through the font families and add the names to the ComboBox
            foreach (FontFamily font in FontFamily.Families)
            {
                comboBoxFonts.Items.Add(font.Name.ToString());

            }

            // set a default selected item
            if (comboBoxFonts.Items.Count > 0)
            {
                comboBoxFonts.SelectedIndex = 0;
            }
            comboBoxFontSize.SelectedIndex = 8;
            this.KeyDown += new KeyEventHandler(ChangePen_KeyDown);

        }


        private void yeoKengEnToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Assembly assembly = Assembly.GetExecutingAssembly();
            var attribute = (GuidAttribute)assembly.GetCustomAttributes(typeof(GuidAttribute), true)[0];
            Clipboard.SetText(attribute.Value.ToString());
        }



        private void ChangeBrush_KeyUp(object sender, KeyEventArgs e)
        {
            if (flagDrawEnabled == true)
            {
                picBoxBrushColor.Image = Properties.Resources.Brush;
                picBoxBrushColor.SizeMode = PictureBoxSizeMode.StretchImage;
                flagDrawingTool = "brush";

            }
        }

        private void ChangePen_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.Control == true && flagDrawEnabled == true)
            {
                picBoxBrushColor.Image = Properties.Resources.Pen;
                picBoxBrushColor.SizeMode = PictureBoxSizeMode.StretchImage;
                flagDrawingTool = "pen";
                pen.Color = brush.Color;
                isDropperSelected = false;


            }
            if (flagDrawingTool == "Polygon" && e.KeyCode == Keys.Enter)
            {
                if (polygonPoints.Count > 2)
                {
                    // Close the polygon by connecting the last point to the first point
                    if (!polygonPoints[0].Equals(polygonPoints[polygonPoints.Count - 1]))
                    {
                        polygonPoints.Add(polygonPoints[0]);
                    }
                    using (Graphics g = Graphics.FromImage(bm))
                    {
                        g.DrawPolygon(pen, polygonPoints.ToArray());
                    }
                    isDrawingPolygon = false; // End polygon drawing mode
                    polygonPoints.Clear(); // Clear points after drawing
                    picBoxMain.Invalidate();
                }
            }
        }


        private void picBoxMain_MouseDown(object sender, MouseEventArgs e)
        {
            startP = e.Location;
            shapestartP = e.Location;
            if (isDropperSelected == true)
            {
                Color dropperColor;
                Point cursorPosition = e.Location;
                Bitmap bmp = (Bitmap)picBoxMain.Image;
                dropperColor = bmp.GetPixel(cursorPosition.X, cursorPosition.Y);
                picBoxBrushColor.BackColor = dropperColor;
                picBoxBrushColor.Image = Properties.Resources.EyeDropper;
                picBoxBrushColor.SizeMode = PictureBoxSizeMode.StretchImage;


            }
            if (flagText == false)
            {
                if (e.Button == MouseButtons.Left)
                {
                    flagDraw = true;

                    if (flagDrawingTool == "Polygon" && e.Button == MouseButtons.Left)
                    {
                        if (!isDrawingPolygon)
                        {
                            isDrawingPolygon = true; // Start drawing mode
                        }
                        if (polygonPoints.Count < maxPolygonSides)
                        {
                            polygonPoints.Add(e.Location);
                            picBoxMain.Invalidate(); // Invalidate to refresh the PictureBox
                        }
                    }
                }

                picBoxMain.Invalidate();


            }


            else
            {
                strText = txtBoxText.Text;
                g = Graphics.FromImage(bm);
                Font font = new Font(selectedFont, selectedFontSize);
                TextColor = picBoxBrushColor.BackColor;
                brush = new SolidBrush(TextColor);
                g.TextRenderingHint = TextRenderingHint.ClearTypeGridFit;
                g.DrawString(strText, font, brush, startP.X, startP.Y);
                g.Dispose();
                picBoxMain.Invalidate();
            }
            if (e.Button == MouseButtons.Right)
            {
                fillStartPoint = e.Location;
            }



        }

        private void picBoxMain_MouseMove(object sender, MouseEventArgs e)
        {


            if (flagDraw == true)
            {
                endP = e.Location;
                g = Graphics.FromImage(bm);
                //g.DrawEllipse(pen, endP.X, endP.Y, 10, 10);
                //g.DrawLine(pen, startP, endP);
                //g.FillEllipse(brush, endP.X, endP.Y, 10, 10);
                if (flagDrawEnabled == true)
                {
                    if (flagErase == false)
                    {
                        if (flagDrawingTool == "brush")
                        {
                            g.FillEllipse(brush, endP.X, endP.Y, brushSize, brushSize);


                        }

                        else if (flagDrawingTool == "pen")
                        {
                            g.DrawLine(pen, startP, endP);

                        }

                    }

                    else
                        g.FillRectangle(brush, endP.X, endP.Y, erasorSize, erasorSize);
                }




                g.Dispose();
                picBoxMain.Invalidate();
            }
            startP = endP;
            g = Graphics.FromImage(bm);



        }



        private void picBoxMain_Paint(object sender, PaintEventArgs e)
        {
            if (flagDraw && flagDrawingTool == "Rectangle")
            {
                // Calculate the rectangle's starting point and size
                int x = Math.Min(shapestartP.X, endP.X);
                int y = Math.Min(shapestartP.Y, endP.Y);
                int width = Math.Abs(endP.X - shapestartP.X);
                int height = Math.Abs(endP.Y - shapestartP.Y);

                e.Graphics.DrawRectangle(pen, x, y, width, height);
            }
            else if (flagDraw && flagDrawingTool == "Ellipse")
            {
                // Calculate the rectangle's starting point and size
                int x = Math.Min(shapestartP.X, endP.X);
                int y = Math.Min(shapestartP.Y, endP.Y);
                int width = Math.Abs(endP.X - shapestartP.X);
                int height = Math.Abs(endP.Y - shapestartP.Y);

                e.Graphics.DrawEllipse(pen, x, y, width, height);
            }


        }

        private void picBoxMain_MouseUp(object sender, MouseEventArgs e)
        {
            flagDraw = false;

            if (flagDrawingTool == "Rectangle")
            {
                // Calculate the rectangle's starting point and size
                int x = Math.Min(shapestartP.X, e.Location.X);
                int y = Math.Min(shapestartP.Y, e.Location.Y);
                int width = Math.Abs(e.Location.X - shapestartP.X);
                int height = Math.Abs(e.Location.Y - shapestartP.Y);

                g = Graphics.FromImage(bm);
                g.DrawRectangle(pen, x, y, width, height);
                g.Dispose();
            }
            else if (flagDrawingTool == "Ellipse")
            {
                // Calculate the rectangle's starting point and size
                int x = Math.Min(shapestartP.X, e.Location.X);
                int y = Math.Min(shapestartP.Y, e.Location.Y);
                int width = Math.Abs(e.Location.X - shapestartP.X);
                int height = Math.Abs(e.Location.Y - shapestartP.Y);

                g = Graphics.FromImage(bm);
                g.DrawEllipse(pen, x, y, width, height);
                g.Dispose();
            }



            picBoxMain.Invalidate();




        }

        private void picBoxClear_Click(object sender, EventArgs e)
        {
           if (picBoxMain.Image != null)
    {
        picBoxMain.Image.Dispose();
        picBoxMain.Image = null;
    }

    // Reset the bitmap and graphics object
    if (bm != null)
    {
        bm.Dispose();
    }
    
    bm = new Bitmap(picBoxMain.Width, picBoxMain.Height);
    g = Graphics.FromImage(bm);
    g.Clear(Color.White); // Clear with a default color, e.g., white
    g.Dispose();

    picBoxMain.Image = bm;

    // Reset the color filter and grayscale flag
    zacolor = 0;
    
    flagText = false;
    isDropperSelected = false;
    flagErase = false;

    // Update UI elements as needed (optional)
    picBoxBrushColor.Image = Properties.Resources.clear;
    picBoxBrushColor.SizeMode = PictureBoxSizeMode.StretchImage;

    // Redraw the picture box
    picBoxMain.Invalidate();
            


        }

        private void picBoxErase_Click(object sender, EventArgs e)
        {
            brush = new SolidBrush(picBoxMain.BackColor);
            picBoxBrushColor.Image = Properties.Resources.erasor;
            picBoxBrushColor.SizeMode = PictureBoxSizeMode.StretchImage;
            flagErase = true;
            flagText = false;
            isDropperSelected = false;
            flagDrawEnabled = true;
            flagDrawingTool = "";
        }

        private void picBoxText_Click(object sender, EventArgs e)
        {
            picBoxBrushColor.Image = Properties.Resources.text;
            picBoxBrushColor.SizeMode = PictureBoxSizeMode.StretchImage;
            flagDraw = false;
            flagText = true;
            isDropperSelected = false;
            flagDrawingTool = "";
        }

        private void picboxbrush_Click(object sender, EventArgs e)
        {
            brush.Color = picBoxBrushColor.BackColor;
            flagDrawingTool = "brush";
            flagErase = false;
            flagText = false;

            flagDrawEnabled = true;

            picBoxBrushColor.Image = Properties.Resources.Brush;
            picBoxBrushColor.SizeMode = PictureBoxSizeMode.StretchImage;
        }

        private void picBoxSave_Click(object sender, EventArgs e)
        {
            picBoxBrushColor.Image = Properties.Resources.save;
            picBoxBrushColor.SizeMode = PictureBoxSizeMode.StretchImage;
            using (SaveFileDialog sfdlg = new SaveFileDialog())
            {
                sfdlg.Title = "Save Dialog";
                sfdlg.Filter = "Image Files(*.BMP)|*.BMP|All files (*.*)|*.*";
                if (sfdlg.ShowDialog(this) == DialogResult.OK)  // Display the dialog and check if the user clicked "Save"
                {
                    using (Bitmap bmp = new Bitmap(picBoxMain.Width, picBoxMain.Height)) // Code inside this block will execute if the user clicked "Save" in the dialog
                    {
                        Rectangle rect = new Rectangle(0, 0, bmp.Width, bmp.Height);  // Define a rectangle that covers the entire Bitmap
                        picBoxMain.DrawToBitmap(bmp, rect); // Copy the contents of the PictureBox into the Bitmap
                        bmp.Save(sfdlg.FileName, ImageFormat.Bmp); // Save the Bitmap to the file specified by the user, using the BMP format
                        MessageBox.Show("File Saved Successfully");
                    }
                }
            }
        }

        private void SelectColor_Click(object sender, EventArgs e)
        {
            PictureBox picBox = (PictureBox)sender;
            string selectedColor = picBox.Tag.ToString();
            switch (selectedColor)
            {
                case "Dropper":
                    isDropperSelected = true;
                    picBoxBrushColor.Image = Properties.Resources.EyeDropper;
                    picBoxBrushColor.SizeMode = PictureBoxSizeMode.StretchImage;
                    break;
                case "Red":

                    pen.Color = picBoxRed.BackColor;
                    picBoxBrushColor.BackColor = pen.Color;
                    picBoxBrushColor.Image = null;
                    brush.Color = picBoxRed.BackColor;
                    flagErase = false;
                    isDropperSelected = false;

                    break;
                case "Blue":

                    pen.Color = picBoxBlue.BackColor;
                    picBoxBrushColor.BackColor = pen.Color;
                    picBoxBrushColor.Image = null;
                    brush.Color = picBoxBlue.BackColor;
                    flagErase = false;
                    isDropperSelected = false;
                    break;
                case "Black":
                    pen.Color = picBoxBlack.BackColor;
                    picBoxBrushColor.BackColor = pen.Color;
                    picBoxBrushColor.Image = null;
                    brush.Color = picBoxBlack.BackColor;
                    flagErase = false;
                    flagText = false;
                    isDropperSelected = false;
                    break;
                case "Green":

                    pen.Color = picBoxGreen.BackColor;
                    picBoxBrushColor.BackColor = pen.Color;
                    picBoxBrushColor.Image = null;
                    brush.Color = picBoxGreen.BackColor;
                    flagErase = false;
                    isDropperSelected = false;
                    break;
                case "Indigo":

                    pen.Color = picBoxIndigo.BackColor;
                    picBoxBrushColor.BackColor = pen.Color;
                    picBoxBrushColor.Image = null;
                    brush.Color = picBoxIndigo.BackColor;
                    flagErase = false;
                    isDropperSelected = false;
                    break;
                case "Orange":

                    pen.Color = picBoxOrange.BackColor;
                    picBoxBrushColor.BackColor = pen.Color;
                    picBoxBrushColor.Image = null;
                    brush.Color = picBoxOrange.BackColor;
                    flagErase = false;
                    isDropperSelected = false;
                    break;
                case "Pink":

                    pen.Color = picBoxPink.BackColor;
                    picBoxBrushColor.BackColor = pen.Color;
                    picBoxBrushColor.Image = null;
                    brush.Color = picBoxPink.BackColor;
                    flagErase = false;
                    isDropperSelected = false;
                    break;
                case "Misc":

                    pen.Color = picBoxMisc.BackColor;
                    picBoxBrushColor.BackColor = pen.Color;
                    picBoxBrushColor.Image = null;
                    brush.Color = picBoxMisc.BackColor;
                    flagErase = false;
                    isDropperSelected = false;
                    break;
                case "Gold":

                    pen.Color = picBoxGold.BackColor;
                    picBoxBrushColor.BackColor = pen.Color;
                    picBoxBrushColor.Image = null;
                    brush.Color = picBoxGold.BackColor;
                    flagErase = false;
                    isDropperSelected = false;
                    break;
                case "Chartreuse":

                    pen.Color = picBoxChartreuse.BackColor;
                    picBoxBrushColor.BackColor = pen.Color;
                    picBoxBrushColor.Image = null;
                    brush.Color = picBoxChartreuse.BackColor;
                    flagErase = false;
                    isDropperSelected = false;
                    break;
                default:
                    isDropperSelected = false;
                    break;
            }


        }

        private void picBoxColorDialog_Click(object sender, EventArgs e)
        {
            if (flagDrawEnabled)
            {
                ColorDialog colorDialog = new ColorDialog();
                picBoxBrushColor.Image = Properties.Resources.Palette;
                picBoxBrushColor.SizeMode = PictureBoxSizeMode.StretchImage;
                if (colorDialog.ShowDialog() == DialogResult.OK)
                {
                    Color selectedColor = colorDialog.Color;

                    // Update the PictureBox's background color
                    picBoxBrushColor.BackColor = selectedColor;
                    picBoxMisc.BackColor = selectedColor;
                    // Clear the PictureBox's image
                    picBoxBrushColor.Image = null;

                    // Update the Brush's color
                    brush.Color = selectedColor;
                    pen.Color = selectedColor;

                }

            }
        }

        private void comboBoxFonts_SelectedIndexChanged(object sender, EventArgs e)
        {
            selectedFont = comboBoxFonts.Text;
        }

        private void comboBoxFontSize_SelectedIndexChanged(object sender, EventArgs e)
        {
            selectedFontSize = int.Parse(comboBoxFontSize.Text);
        }

        private void brushSizeTrackBar_Scroll(object sender, EventArgs e)
        {
            brushSize = brushSizeTrackBar.Value;
            brushSizeNumber.Text = brushSize.ToString();

        }

        private void pictBoxLoad_Click(object sender, EventArgs e)
        {
            OpenFileDialog ofd = new OpenFileDialog();
            ofd.Filter = "Image Files|*.bmp;*.jpg;*.jpeg;*.png;*.gif;*.tiff|All files|*.*";


            DialogResult result = ofd.ShowDialog();
            if (result == DialogResult.OK)
            {
                Bitmap img = new Bitmap(ofd.FileName);
                switch (flagLoaded)
                {
                    case true:

                        g = Graphics.FromImage(bm);
                        g.DrawImage(img, 0, 0, picBoxMain.Width, picBoxMain.Height);


                        break;
                    case false:
                        g = Graphics.FromImage(bm);
                        g.DrawImage(img, 0, 0, picBoxMain.Width, picBoxMain.Height);
                        flagLoaded = true;
                        break;
                }
                picBoxMain.Image = bm;
                picBoxMain.Invalidate();
                g.Dispose();
                img.Dispose();
            }
        }

        private void comboBoxDrawShape_SelectedIndexChanged(object sender, EventArgs e)
        {
            drawshape = comboBoxDrawShape.Text;
            switch (drawshape)
            {
                case "Rectangle":
                    flagDrawingTool = "Rectangle";
                    break;
                case "Ellipse":
                    flagDrawingTool = "Ellipse";
                    break;
                case "Polygon":
                    flagDrawingTool = "Polygon";
                    break;
                default:
                    flagDrawingTool = "";
                    break;


            }

            flagText = false;
            flagDraw = false;
            isDropperSelected = false;
            polygonPoints.Clear();
        }

        private void picBoxFill_Click(object sender, EventArgs e)
        {
            picBoxBrushColor.Image = Properties.Resources.fill;
            picBoxBrushColor.SizeMode = PictureBoxSizeMode.StretchImage;

            if (bm == null)
                return;

            // Get the color to fill
            Color fillColor = picBoxBrushColor.BackColor;

            // Get the target color at the starting point
            Color targetColor = bm.GetPixel(fillStartPoint.X, fillStartPoint.Y);

            // Perform flood fill
            FloodFill(bm, fillStartPoint, targetColor, fillColor);

            // Refresh the PictureBox to show the updated image
            picBoxMain.Invalidate();
        }

        private void FloodFill(Bitmap bmp, Point pt, Color targetColor, Color replacementColor)
        {
            bool[,] VisitedPixel = new bool[bmp.Width, bmp.Height];
            Stack<Point> pixels = new Stack<Point>();
            // Ensure targetColor matches the actual color at the starting point
            pixels.Push(pt);

            while (pixels.Count > 0)
            {
                Point a = pixels.Pop();
                if (a.X >= 0 && a.X < bmp.Width && a.Y >= 0 && a.Y < bmp.Height && !VisitedPixel[a.X, a.Y]) // Check bounds
                {
                    if (bmp.GetPixel(a.X, a.Y) == targetColor)
                    {
                        bmp.SetPixel(a.X, a.Y, replacementColor);
                        VisitedPixel[a.X, a.Y] = true;
                        pixels.Push(new Point(a.X - 1, a.Y)); // Left
                        pixels.Push(new Point(a.X + 1, a.Y)); // Right
                        pixels.Push(new Point(a.X, a.Y - 1)); // Up
                        pixels.Push(new Point(a.X, a.Y + 1)); // Down
                    }
                }
            }


        }



        private void erasorSize_Click(object sender, EventArgs e)
        {
            PictureBox picBox = (PictureBox)sender;
            flagText = false;
            flagDraw = false;
            isDropperSelected = false;



            // Retrieve the tag and convert it to an integer
            if (int.TryParse(picBox.Tag.ToString(), out erasorSize))
            {
                // Handle different erasor sizes using a switch case
                switch (erasorSize)
                {
                    case 10:
                        // Set erasor size to 10
                        erasorSize = 10;
                        break;
                    case 30:
                        // Set erasor size to 30
                        erasorSize = 30;
                        break;
                    case 50:
                        // Set erasor size to 50
                        erasorSize = 50;
                        break;
                    default:
                        // Handle any other cases (if necessary)
                        break;
                }
            }
        }

        private void picBoxLightDark_Click(object sender, EventArgs e)
        {
            bgMode = !bgMode;

            if (bgMode == true)
            {
                this.BackColor = SystemColors.Control;
                picBoxBrushColor.Image = Properties.Resources.Dark;
                picBoxBrushColor.SizeMode = PictureBoxSizeMode.StretchImage;
                picBoxLightDark.Image = Properties.Resources.Dark;
                picBoxLightDark.SizeMode = PictureBoxSizeMode.StretchImage;

            }
            else
            {
                this.BackColor = Color.FromArgb(255, 100, 100, 100);
                picBoxBrushColor.Image = Properties.Resources.Light;
                picBoxBrushColor.SizeMode = PictureBoxSizeMode.StretchImage;
                picBoxLightDark.Image = Properties.Resources.Light;
                picBoxLightDark.SizeMode = PictureBoxSizeMode.StretchImage;
            }
        }

        int zacolor = 0;
     

        private void btnTransform_Click(object sender, EventArgs e)
        {
            Bitmap oImage = (Bitmap)picBoxMain.Image;
            if (oImage == null)
                return;

            // Create a copy of the original image to apply the filter
            
            Bitmap filteredImage = new Bitmap(oImage.Width, oImage.Height);

            
                // Apply color filter
                if (picBoxMain.Image == null)
                    return;

                // Create a copy of the original image to apply the filter



                // Initialize a graphics object from the filtered image
                using (Graphics g = Graphics.FromImage(filteredImage))
                {
                    // Define a color matrix for the desired transformation
                    ColorMatrix colorMatrix = new ColorMatrix();




                    // Set the color matrix based on the selected filter
                    switch (zacolor)
                    {
                        case 0x00FF0000: // Red filter
                            colorMatrix = new ColorMatrix(new float[][]
                            {
                    new float[] {1, 0, 0, 0, 0},
                    new float[] {0, 0, 0, 0, 0},
                    new float[] {0, 0, 0, 0, 0},
                    new float[] {0, 0, 0, 1, 0},
                    new float[] {0, 0, 0, 0, 1}
                            });
                            break;
                        case 0x000000FF: // Blue filter
                            colorMatrix = new ColorMatrix(new float[][]
                            {
                    new float[] {0, 0, 0, 0, 0},
                    new float[] {0, 0, 0, 0, 0},
                    new float[] {0, 0, 1, 0, 0},
                    new float[] {0, 0, 0, 1, 0},
                    new float[] {0, 0, 0, 0, 1}
                            });
                            break;
                        case 0x007FFF00: // Chartreuse filter
                            colorMatrix = new ColorMatrix(new float[][]
                            {
                    new float[] {0, 0, 0, 0, 0},
                    new float[] {0, 1, 0, 0, 0},
                    new float[] {0, 0, 0, 0, 0},
                    new float[] {0, 0, 0, 1, 0},
                    new float[] {0, 0, 0, 0, 1}
                            });
                            break;
                        default:
                            // No filter applied, use identity matrix
                            colorMatrix = new ColorMatrix(new float[][]
                            {
                    new float[] {1, 0, 0, 0, 0},
                    new float[] {0, 1, 0, 0, 0},
                    new float[] {0, 0, 1, 0, 0},
                    new float[] {0, 0, 0, 1, 0},
                    new float[] {0, 0, 0, 0, 1}
                            });
                            break;

                    }

                    // Apply the color matrix
                    ImageAttributes attributes = new ImageAttributes();
                    attributes.SetColorMatrix(colorMatrix);

                    // Draw the image with the color matrix applied
                    g.DrawImage(oImage, new Rectangle(0, 0, filteredImage.Width, filteredImage.Height), 0, 0, oImage.Width, oImage.Height, GraphicsUnit.Pixel, attributes);
                

                // Update the picture box with the filtered image
                picBoxMain.Image = filteredImage;
                picBoxMain.Refresh();
            }
        }
    

        private void SelectColorFilter_Click(object sender, EventArgs e)
        {
            PictureBox picBox = (PictureBox)sender;
            string selectedColorFilter = picBox.Tag.ToString();

            switch (selectedColorFilter)
            {
                case "RedF":
                    zacolor = 0x00FF0000;
                    isDropperSelected = false;
                    flagErase = false;
                  
                    break;
                case "BlueF":
                    zacolor = 0x000000FF;
                    isDropperSelected = false;
                    flagErase = false;
                   
                    break;
                case "ChartreuseF":
                    zacolor = 0x007FFF00;
                    isDropperSelected = false;
                    flagErase = false;

                    break;
                default:
                    
                    isDropperSelected = false;
                    flagErase = false;
                    break;
            }
        }
    }
}
